function [dataDir,imagenetDir] = setupPaths()

% set the correct paths here
matconvnetPath = 'UNSET' ;
vlfeatPath     = 'UNSET' ;
dataDir        = 'UNSET' ;
imagenetDir    = 'UNSET' ;

% example paths:
	 % matconvnetPath = '~/src/matconvnet170808/matconvnet' ;
	 % vlfeatPath     = '~/src/vlfeat/toolbox';
	 % dataDir        = '/scratch/shared/slow/david/anchornet-clean/';
	 % imagenetDir    = '/datasets/imagenet12/ILSVRC2012/images';

if any(strcmp({matconvnetPath,vlfeatPath,dataDir},'UNSET')) 
	msg = sprintf('please download and compile MATCONVNET and VLFEAT libraries. After that set the "matconvnetPath" and "vlfeatPath" to point to the corresponding library directories\n');
	msg = sprintf('%sfurthermore set the "imagenetDir" to point to the "images" directory of ILSVRC2012 and set "dataDir" which stores the experiment results\n',msg);
	error(msg);
end

oldpth = cd(vlfeatPath);
vl_setup;
cd(oldpth);

oldpth = cd(fullfile(matconvnetPath,'matlab'));
vl_setupnn;
cd(oldpth);

curdir = fileparts(mfilename('fullpath'));

addpath(fullfile(curdir,'cnntools'));
addpath(fullfile(curdir,'experiments'));
addpath(fullfile(curdir,'matlab'));
addpath(fullfile(curdir,'eval'));
addpath(fullfile(curdir,'dsp-code'));

end