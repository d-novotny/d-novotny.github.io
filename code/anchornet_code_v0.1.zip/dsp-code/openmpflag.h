#pragma once
#define __OPEN_MP
