function [net,derOutputs] = initializeAnchorNet(varargin)

opts = struct();

opts.sourceModelPath = '';
opts.covFile = '';

opts.upNorm           = true;
opts.imSize           = 0;
opts.whitenNorm       = true;
opts.whitenFullFilter = false;
opts.whtStrength      = 1e5;
opts.nKeypoints       = 50;
opts.fSize            = 1;
opts.killKPLR         = -1;

opts.auxNegMax0 = true;
opts.auxNegAfterBorder = true;
opts.kpAct = 'none';

opts.obClasses = [];
opts.outSize   = 0;
opts.maxAppDim = inf;
opts.appFeats  = {};
opts.fullBPLR  = 0;
opts.hcValve   = 0;

opts.DO_objective = -1;
opts.DO_diversity = -1;
opts.DO_auxNeg    = -1;
opts.DO_sharing   = -1;

opts.normHmaps         = false;
opts.normKeypoints     = false;
opts.globNormKeypoints = false;
opts.pNorm             = 2; 

opts.sharing         = -1;
opts.sharingOrth     = 0;
opts.sharingValve    = 0;
opts.sharingGlobNorm = false;
opts.sharingDrop     = 0;
opts.sharingFSize    = 1;

opts.initKPWith = {};

opts.fixGroups = false;

opts = vl_argparse(opts,varargin);

derOutputs = {};

if exist(opts.sourceModelPath)~=2
	fprintf('downloading the source model (resnet50)\n');
	resnet50_url = 'http://www.robots.ox.ac.uk/~david/anchornet/imagenet-resnet-50-dag.mat' ;
	urlwrite( resnet50_url, opts.sourceModelPath );
end

if exist(opts.covFile)~=2
	fprintf('downloading the estimated feature covariances (resnet50)\n');
	resnet50cov_url = 'http://www.robots.ox.ac.uk/~david/anchornet/imagenet-resnet-50-dag.mat.covest.mat' ;
	urlwrite( resnet50cov_url, opts.covFile );
end

net = load(opts.sourceModelPath);
net = dagnn.DagNN.loadobj(net);
net.removeLayer('pool5');
net.removeLayer('fc1000');
net.removeLayer('prob');

nKey = opts.nKeypoints; 

assert(~isempty(opts.obClasses));
obClasses_ = opts.obClasses;
obClasses_ = sort(obClasses_(:));
nKey = nKey*numel(obClasses_);
obClassMask = ones(opts.nKeypoints,1)*obClasses_(:)';
obClassMask = obClassMask(:);
net.meta.obClassMask = obClassMask;

if ~isempty(opts.imSize)
	net.meta.normalization.imageSize = [opts.imSize opts.imSize 3 1];
end

opts_ = struct();
opts_.maxAppDim = opts.maxAppDim;
opts_.outSize   = opts.outSize;
opts_.netName = 'resnet_50';
opts_.appFeats = opts.appFeats;
opts_.predSize = [];
covStruct = load(opts.covFile);
[net,appdims] = addNetUpsamples(net,opts_,covStruct,false,true);

hcLayerIn = 'hc';
hcLayer = 'hc_GK';
vsz    = net.getVarSizes({'data',net.meta.normalization.imageSize});   
hcSize = vsz{net.getVarIndex(hcLayerIn)}; 
hcDim  = hcSize(3);
net.addLayer(hcLayer,dagnn.GradKill('fac',opts.hcValve),hcLayerIn,hcLayer);
pad_    = ((opts.fSize-1)/2) ;

kpinDim = hcDim;

filters = randn(opts.fSize,opts.fSize,kpinDim,nKey,'single')*0.01;  
net.addLayer('keyPointModels', ...
	  		 dagnn.ConvWhiten(...
		  		 'size', size(filters), ...
		  		 'hasBias', true, ...
		  		 'stride', 1, ...
		  		 'pad',  pad_, ...
		  		 'whtStrength', opts.whtStrength, ...
		  		 'nrm', true, ...
		  		 'dilate', 1, ....
		  		 'whitengroups', net.meta.obClassMask, ...
				 'nrmFull', opts.whitenFullFilter, ...
		  		 'p', 1, ...
		  		 'fixGroups', opts.fixGroups ), ... 
		  		 hcLayer,'keyPointModels',{'keyPointModels_f','keyPointModels_b'} ) ;
f = net.getParamIndex('keyPointModels_f') ;
fb = net.getParamIndex('keyPointModels_b') ;

net.params(f).value = filters ;
net.params(f).learningRate  = 1;
net.params(fb).value = 1*ones(nKey,1,'single') ; 
net.params(fb).learningRate = 1; 
if opts.killKPLR > 0
	net.params(f).learningRate  = opts.killKPLR;
	net.params(fb).learningRate = opts.killKPLR;
end

if ~isempty(opts.initKPWith)
	f = [];
	if iscell(opts.initKPWith)
	elseif ischar(opts.initKPWith)
		opts.initKPWith = {opts.initKPWith};
	else
		error('bad input format');
	end
	filters = {}; biases = {};
	initmus = {}; initcovs = {};
	for ini=1:numel(opts.initKPWith)
		fprintf('init with %s\n',opts.initKPWith{ini});  
		neti = load(opts.initKPWith{ini});
		neti = dagnn.DagNN.loadobj(neti.net);
		kpl = neti.getLayerIndex('keyPointModels');
		kpprm = neti.layers(kpl).paramIndexes;
		kpf = neti.params(kpprm(1)).value;
		kpb = neti.params(kpprm(2)).value;
		filters{end+1} = kpf;
		biases{end+1} = kpb;
	end
	filters = cat(4,filters{:});
	biases  = cat(1,biases{:});
	f = net.getParamIndex('keyPointModels_f') ;
	assert(isequal(size(filters),size(net.params(f).value)));
	net.params(f).value = filters ;
	fb = net.getParamIndex('keyPointModels_b') ;
	assert(isequal(size(biases),size(net.params(fb).value)));
	net.params(fb).value = biases ;  
end

net.addLayer('keyPointRelu', dagnn.SoftPlus(), 'keyPointModels', 'keyPointRelu') ;

net = adjustLRs(net,opts);

net.addLayer( 'borderFilter', dagnn.Prod(), {'keyPointRelu', 'mask'}, 'keyPointReluMasked');
globMaxPoolLayer = 'keyPointReluMasked';
net.meta.useMask = true;

if opts.DO_diversity > 0
	net = addGaussConv(net,'keyPointRelu','keyPointModelsDecorrG',ceil(mean(opts.outSize)/30),nKey,false);
	net.addLayer('LOSS_diversity', dagnn.WhitenHMap(), {'keyPointModelsDecorrG', 'label'}, 'LOSS_diversity');
	derOutputs(end+1,:) = {'LOSS_diversity', opts.DO_diversity};
end

if opts.DO_sharing > 0

	assert(~isempty(opts.initKPWith));

	net.addLayer('sharingValve', dagnn.GradKill('fac',opts.sharingValve),'keyPointRelu','keyPointReluSharing' ); 

	net.renameVar('keyPointReluSharing','keyPointReluSharingNoCenter');
	net.addLayer('keyPointReluSharingCenter',dagnn.ConvBias, 'keyPointReluSharingNoCenter', 'keyPointReluSharing', {'keyPointReluSharingCenter_mu'} );
	f = net.getParamIndex('keyPointReluSharingCenter_mu');
	net.params(f).value        = zeros(1,1,nKey,1,'single');
	net.params(f).trainMethod  = 'average';

	net.addLayer('keyPointReluSharingDrop',dagnn.HMapKill('rate',opts.sharingDrop),'keyPointReluSharing','keyPointReluSharingDrop');

	pad_ = floor((opts.sharingFSize-1)/2);
	assert(round(pad_)==pad_);
	nshrdim = nKey;

	fprintf('\n\n\n WARNING: NORM WEIGHTS HERE set to FALSE \n\n\n');

	filters = randn(opts.sharingFSize,opts.sharingFSize,nshrdim,opts.sharing,'single')*0.01;  
	net.addLayer('shareEncoder', ...
		  		 dagnn.ConvWhiten(...
			  		 'size', size(filters), ...
			  		 'hasBias', false, ...
			  		 'stride', 1, ... 
			  		 'pad',  pad_, ...
			  		 'whtStrength', opts.sharingOrth, ...
			  		 'nrm', true, ...
			  		 'whitengroups', [], ...
			  		 'normweights', false, ...
			  		 'p', 1 ), ...  
			  		 'keyPointReluSharingDrop','shareEncoder',{'shareEncoder_f','shareEncoder_b'} ) ;
	f = net.getParamIndex('shareEncoder_f') ; 
	net.params(f).value = filters ; 

	net = addDeConv(net,'shareEncoder','shareDecoder',[opts.sharingFSize opts.sharingFSize nshrdim opts.sharing],pad_,1e-2,1,1,false);
	net.setLayerParams('shareDecoder',{'shareEncoder_f'});  

	if opts.sharingGlobNorm
		fprintf('shr glob norm\n');
		net.addLayer('shareDecoderNrm', dagnn.GlobNorm ,'shareDecoder','shareDecoderNrm');
		net.addLayer('keyPointReluSharingNrm',  dagnn.GlobNorm ,'keyPointReluSharing','keyPointReluSharingNrm');  
		net.addLayer( 'LOSS_recon', dagnn.LayerDistWeightedC2('p',2,'normByNPix',true,'c',inf, 'loss', 'l2'), {'shareDecoderNrm', 'keyPointReluSharingNrm'}, 'LOSS_recon' );
	else
		net.addLayer( 'LOSS_recon', dagnn.LayerDistWeightedC2('p',2,'normByNPix',true,'c',inf, 'loss', 'l2'), {'shareDecoder', 'keyPointReluSharing'}, 'LOSS_recon' );
	end
	net.addLayer('isPosLabel', dagnn.OnlyPositive(), 'labelSum', 'isPosLabel'); 
	net.addLayer('LOSSaux_reconPositive',dagnn.Prod,{'LOSS_recon','isPosLabel'},'LOSSaux_reconPositive');
	derOutputs(end+1,:) = {'LOSSaux_reconPositive',opts.DO_sharing};

	% if true
	% 	str = net.print({'data',[net.meta.normalization.imageSize(1:2) 3 1], ...
	% 					 }, ... %'gtDepth',[net.meta.normalization.imageSize(1:2) 1 1] }, ...
	% 			         'format','dot');
	% 	displayDot(str,fullfile('~/junk/','resnetwipDiag'));
	% 	error();
	% end
	% assert(~isempty(lastGVar));
	% keyboard 

end

if opts.DO_objective > 0

	net.addLayer('maxKey', ...
				  dagnn.Pooling(...
				  'method', 'max', ...
				  'poolSize', opts.outSize, ...
				  'stride', [100 100], ...
				  'pad', [0 0]), ...
				  globMaxPoolLayer,'maxKey') ;

	net.addLayer('quantileMask', dagnn.QuantileMask( 'quantile', 1, 'multiclass', true ), {'maxKey','label'} ,{'qMaskApp','qMaskGeom'} ) ;

	net.addLayer('maxKeyMasked',dagnn.Prod,{'maxKey','qMaskApp'},'maxKeyMasked');
		
	filters = ones(1,1,nKey,1,'single');
	net.addLayer('sumKey', ...
				  dagnn.Conv(...
				  'size', size(filters), ...
				  'hasBias', false, ...
				  'stride', [1 1], ...
				  'pad', [0 0]), ...
				  'maxKeyMasked','sumKey','sumKeyf' ) ;
	f = net.getParamIndex('sumKeyf') ;
	net.params(f).value = filters ;
	net.params(f).learningRate = single(0) ; 

	net.addLayer('LOSS_objective', dagnn.LossAnchorNet('loss','corr'), {'sumKey','labelSum'}, 'LOSS_objective') ;

	derOutputs(end+1,:) = {'LOSS_objective', opts.DO_objective};

end

if opts.DO_auxNeg > 0	
	net.addLayer( 'LOSS_auxNeg', dagnn.NegPenalty('max0',true), {'keyPointReluMasked','label'} , 'LOSS_auxNeg');	
	derOutputs(end+1,:) = {'LOSS_auxNeg', opts.DO_auxNeg};
end

for vari=1:numel(net.vars)
	vnm = net.vars(vari).name;
	if net.vars(vari).fanout == 0 && ~ismember(vnm,derOutputs(:,1))
		fprintf('Warning! %s has no fanout -> ZERO WEIGHT\n',vnm);
		derOutputs(end+1,:) = {vnm,0};
	end
end

for di = 1:size(derOutputs,1)
	fprintf('%50s %1.2e\n',derOutputs{di,1},derOutputs{di,2});
	assert(isfinite(net.getVarIndex(derOutputs{di,1})));
end

derOutputs = derOutputs';
derOutputs = derOutputs(:)';

net.meta.nKeypoints = nKey;
net.meta.netOpts = opts;

end


function net = adjustLRs(net,opts)

if opts.fullBPLR <= 0
	keeplr = {'keyPointModels_f','keyPointModels_b','keyPointModelsShare_f','keyPointModelsShare_b'};
	for ip=1:length(net.params)
		if ~any(strcmp(net.params(ip).name,keeplr)) 
			net.params(ip).learningRate = 0;
			fprintf('zeroing learning rate %s\n',net.params(ip).name ); 
		else
		end
	end	
else
	keeplr = {'keyPointModels_f','keyPointModels_b','keyPointModelsShare_f','keyPointModelsShare_b','sumKeyf'};
	% for uplayer = opts.upsampleLayers, 
	% 	keeplr = [keeplr, sprintf('keyPointModels_f%d',uplayer)]; 
	% 	keeplr = [keeplr, sprintf('keyPointModels_b%d',uplayer)]; 
	% end;


	fprintf('\n\n\nWARNING!!! WHICH ONE IS RIGHT??\n\n\n');

	% for ip=1:length(net.params)
	% 	if any(strcmp(net.params(ip).name,keeplr))
	% 		fprintf('keeping learning rate %s - %1.2e\n',net.params(ip).name,net.params(ip).learningRate );
	% 	else
	% 		net.params(ip).learningRate = opts.fullBPLR; %*net.params(ip).learningRate;
	% 		if strfind(net.params(ip).name,'moments')
	% 			net.params(ip).learningRate = 0.01*opts.fullBPLR;
	% 		end
	% 		fprintf('setting learning rate %s - %1.2e\n',net.params(ip).name,net.params(ip).learningRate );
	% 	end
	% end

	for ip = 1:length(net.params)
		if any(strcmp(net.params(ip).name,keeplr))
			fprintf('keeping learning rate %s - %1.2e\n',net.params(ip).name,net.params(ip).learningRate );
		else
			net.params(ip).learningRate = opts.fullBPLR*net.params(ip).learningRate;
			% if strfind(net.params(ip).name,'moments')
			% 	net.params(ip).learningRate = 0.01*opts.fullBPLR;
			% end
			fprintf('setting learning rate %s - %1.2e\n',net.params(ip).name,net.params(ip).learningRate );
		end
	end	
end

end


function net = addConv(net,bottom,top,sz,pad,scale,lr,stride,lrb,bn,hasb)

	if nargin <= 5
		scale = 0.01;
	end 
	if nargin <= 6
		lr = 1;
	end 
	if nargin <= 7
		stride = 1;
	end 
	if nargin <= 8
		lrb = lr*2;
	end 
	if nargin <= 9
		bn = false;
	end 
	if nargin <= 10
		hasb = true;
	end 

	if bn
		topnm = [top '_cnv'];
	else
		topnm = top;
	end

	fname = [topnm '_f'];
	bname = [topnm '_b'];

	if ~hasb

		net.addLayer(topnm, dagnn.Conv('size', sz, 'pad', pad, 'stride', stride, 'hasBias', false), bottom, topnm, {fname});

			f = net.getParamIndex(fname) ;
		net.params(f).value = randn(sz, 'single')*scale ;
		net.params(f).learningRate = lr ;
		net.params(f).weightDecay = 1 ;
		net.params(f).trainMethod = 'gradient'; 

	else

		net.addLayer(topnm, dagnn.Conv('size', sz, 'pad', pad, 'stride', stride), bottom, topnm, {fname,bname});

		f = net.getParamIndex(fname) ;
		net.params(f).value = randn(sz, 'single')*scale ;
		net.params(f).learningRate = lr ;
		net.params(f).weightDecay = 1 ;
		net.params(f).trainMethod = 'gradient'; 

		f = net.getParamIndex(bname) ;
		net.params(f).value = zeros(sz(4), 1, 'single') ;
		net.params(f).learningRate = lrb ;
		net.params(f).weightDecay = 0 ;
		net.params(f).trainMethod = 'gradient';

	end

	if bn
		net = addBN(net,topnm,top,sz);
	end

end


function net = addGaussConv(net,bottom,top,sz,nF,preserveMode,fsz)

	if nargin <= 5
		preserveMode = false;
	end

	fname = [top '_f'];

	sig = sz;
	sz = sig*2;

	if nargin <= 6
		fsz = sz*2+1;
	end

	h = single(fspecial('gaussian',fsz,sig));
	[u,v] = eig(h);
	h1 = u(:,end)*sqrt(v(end));

	fltVert = repmat(h1,[1 1 1 nF]) ;
	fltHorz = repmat(h1(:)',[1 1 1 nF]) ;

	if true
		h_ = h1*h1';
		df = h-h_;
		assert(norm(df(:))<=1e-5);
	end

	net.addLayer(top,dagnn.GaussFilter('flt',{fltVert,fltHorz},'preserveMode',preserveMode),bottom,top);

end

function f1 = decomposeFilter(f)

	[u,v] = eig(f);
	f1 = u(:,end)*sqrt(v(end));

	if true
		f_ = f1*f1';
		df = f-f_;
		assert(norm(df(:))<=1e-5,'filter not decomposable');
	end

end

function [net,appdims] = addNetUpsamples(net,opts,covStruct,whiten,normDesc)

    maxdim = opts.maxAppDim;

    % predIdx = net.getVarIndex('prediction');
    outSize = opts.outSize;
    dmapSize = outSize;

    appdims = [];

    newUpVars = {};
    for upVar = opts.appFeats 

    	fprintf('upsampling var %s\n',upVar{1});

    	vsz = net.getVarSizes({'data',net.meta.normalization.imageSize});   
	    % outSize = vsz{predIdx};

	    fsize = vsz{net.getVarIndex(upVar{1})};

		if fsize(3) > maxdim
			
			covi           = find(strcmp(covStruct.VARS,upVar{1}));
			assert(numel(covi)==1);
			mu_            = covStruct.mus{covi}; 
			cv_            = covStruct.covs{covi};
			[wht,whtt]     = getPCATrans(cv_,mu_,maxdim,whiten);
			
			fprintf('getting PCA transform\n');
			whtlname       = [upVar{1} '_pca'];
			net            = addPCATrans(net,upVar{1},whtlname,wht,whtt);
			upVar_         = whtlname;
			appdims(end+1) = maxdim;
		
		else
		
			upVar_         = upVar{1};
			appdims(end+1) = fsize(3);
		
		end

		upName = [upVar_ '_up'];

		spatSize = dmapSize(1:2);
		if ~isempty(opts.predSize)
			spatSize = opts.predSize;
		end

		fprintf('setting SPT to < %d ; %d > \n',spatSize(1),spatSize(2));

		net.addLayer( upName, dagnn.SpaTransformerFixedG('outSz',spatSize), upVar_, upName);
		
		if normDesc
			upNameN = [upName '_nrm'];
			net.addLayer(upNameN,dagnn.LPNorm,upName,upNameN);
			newUpVars{end+1} = upNameN;
		else
			newUpVars{end+1} = upName;
		end
	end

	if whiten
		net.addLayer('hcWht',dagnn.Concat,newUpVars,'hcWht');
	else
		net.addLayer('hc',dagnn.Concat,newUpVars,'hc');
	end

end