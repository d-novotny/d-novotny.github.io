function [y,Ts] = getBatchAnchorNet(imdb, images, varargin)
% GET_BATCH  Load, preprocess, and pack images for CNN evaluation

opts.imageSize = [512, 512] - 128 ;
opts.rgbMean = [] ;
opts.useGpu = false ;
opts.flip = false;
opts.randSample = true;
opts.mask = [1 1 1];
opts.border = [0 0];
opts.normCorr = false;
opts.nKeypoints = -1;
opts.obClassMask = [];
opts.unfoldLabel = false;

opts = vl_argparse(opts, varargin);

if ~isempty(opts.rgbMean)
  if numel(opts.rgbMean)==3
    opts.rgbMean = reshape(opts.rgbMean, [1 1 3]) ;
  else
    opts.rgbMean = imresize(opts.rgbMean, opts.imageSize(1:2), 'bilinear');
  end
else
  opts.rgbMean = zeros(1,1,3,'single');
end

% space for images
ims       = zeros(opts.imageSize(1), opts.imageSize(2), 3, numel(images), 'single') ;
labels    = cell(1,numel(images));
classInds = cell(1,numel(images));
masks     = ones(opts.mask(1), opts.mask(2), opts.mask(3), numel(images), 'single') ; 

imsets = {};

si = 1 ;
for i = 1:numel(images)

  set_   = imdb.images.set  (images(i));
  class_ = imdb.images.class(images(i));

  assert(set_==1 || set_ == 2);

  if opts.randSample && set_==1
    if class_ == 0
      possibleIms = find(imdb.images.set==set_ & imdb.images.class == class_);
      randClass = 0;
    else
      assert(ismember(class_,1:20));
      unqCls    = unique(opts.obClassMask);
      randClass = vl_colsubset(unqCls(:)',1);
      possibleIms = imdb.images.set==set_ & imdb.images.class == randClass; 
      possibleIms = find(possibleIms);
    end
    selim = possibleIms(randi([1 numel(possibleIms)]));
  else
    selim = images(i);
    randClass = imdb.images.class(selim);
  end

  assert(imdb.images.set  (selim) == set_   );
  assert(imdb.images.class(selim) == randClass, 'a class problem: %d ~= %d',imdb.images.class(selim),randClass);
  
  class_ = imdb.images.class(selim);
  classInds{end+1} = class_;
  imsets{end+1} = set_;
  
  imageid = imdb.images.id(selim);
  okim   = find(imdb.images.id==imageid);
  imname = imdb.images.name{okim};
  assert(numel(okim)==1);

  assert(imdb.images.set(okim)   == set_   );
  assert(imdb.images.class(okim) == class_ );

  if iscell(imdb.imageDir)
    rgbPath = fullfile(imdb.imageDir{class_},imname);
  else
    rgbPath = fullfile(imdb.imageDir,[imname]);
  end

  switch set_
    case 1
      assert(~isempty(strfind(rgbPath,'/train/')));
    case 2
      assert(~isempty(strfind(rgbPath,'/val/')));
    otherwise
      error();
  end

  rgb     = single(imread(rgbPath)) ;
  if size(rgb,3) == 1
    rgb = repmat(rgb,[1 1 3]);
  end

  if false
    figure(1);clf;
    imagesc(uint8(rgb));
    if class_ == 0
      clsname = 'neg';
    else
      clsname = imdb.classes.name{class_};
    end
    fprintf('%s\n',clsname); 
    title(sprintf('%s',clsname));
    drawnow;
  end
  
  ims(:,:,:,si) = bsxfun(@minus,resnetCrop(rgb,opts),opts.rgbMean);
  masks(:,:,:,si) = 1;

  if class_ == 0
    label = -ones( opts.nKeypoints,1,'single' );
  else
    label = zeros( opts.nKeypoints,1,'single' );
    labelMask = opts.obClassMask==class_;
    assert(numel(labelMask)==opts.nKeypoints);
    label(labelMask) = 1;
  end

  if false
    figure(1); clf;
    subplot(1,3,1);
    imagesc(uint8(rgb));
    subplot(1,3,2);
    imagesc(uint8(ims(:,:,:,si)));
    if class_==0
      dscpas = 'NEGATIVE';
      dscinet = 'NEGATIVE';
    else
      dscpas  = sprintf('%s',imdb.classes.description{imdb.images.labelINet(selim)});
      dscinet = sprintf('%s',imdb.classes.namePascal{imdb.images.class(selim)});
    end
    title(sprintf('%s - %s',dscpas,dscinet));
    drawnow;
    outdir = '~/junk/resnetdbg/'; %mkdir(outdir);
    saveas(1,fullfile(outdir,sprintf('im%d.png',selim)));
  end

  labels{si} = reshape(label,[1 1 numel(label)]); %(1,1,:,si) = label; 

  si = si + 1 ;

end

if true % some checks
  classInds = single(cat(2,classInds{:}));
  imsets = cat(2,imsets{:});
  % fprintf('imsets    = '); fprintf('%d ',imsets(:)'); fprintf('\n');
  % fprintf('classInds = '); fprintf('%d ',classInds(:)'); fprintf('\n');
  assert(all(imsets==imdb.images.set(images(1))));
end

labels    = single(cat(4,labels{:}));

if opts.useGpu
  ims    = gpuArray(ims) ;
  labels = gpuArray(labels) ;
  masks  = gpuArray(masks);
end

y = {'data', ims};
if opts.mask > 0
  % masks = repmat(masks, [1 1 opts.mask 1]);
  y = {y{:},'mask', masks} ;  
end
y = {y{:},'label', labels} ;
  
labelsSum = labels==-1;
labelsSum = any(labelsSum,3);
labelsSum = -2 * single(labelsSum) + 1;
if opts.normCorr
  labelsSum(labelsSum==-1) = (1/numel(unique(opts.obClassMask))) * labelsSum(labelsSum==-1); 
end

y = {y{:},'labelSum', labelsSum} ;

end


function imt = resnetCrop(imt,opts)

  w = size(imt,2) ;
  h = size(imt,1) ;
  factor = [(opts.imageSize(1)+opts.border(1))/h ...
            (opts.imageSize(2)+opts.border(2))/w];
  factor = max(factor) ;

  if any(abs(factor - 1) > 0.0001)
    imt = imresize(imt, ...
                   'scale', factor, ...
                   'method','bicubic') ;
  end

  % crop & flip
  w = size(imt,2) ;
  h = size(imt,1) ;
  sz = round(min(opts.imageSize(1:2)' .* (1-0.03+0.06*rand(2,1)), [h;w])) ;
  dx = randi(w - sz(2) + 1, 1) ;
  dy = randi(h - sz(1) + 1, 1) ;
 
  sx = round(linspace(dx, sz(2)+dx-1, opts.imageSize(2))) ;
  sy = round(linspace(dy, sz(1)+dy-1, opts.imageSize(1))) ;

  imt = imt(sy,sx,:);

end
