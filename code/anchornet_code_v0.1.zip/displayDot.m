% -------------------------------------------------------------------------
function displayDot(str,pth)
% -------------------------------------------------------------------------
%mwdot = fullfile(matlabroot, 'bin', computer('arch'), 'mwdot') ;
dotexe = 'dot' ;

in=[pth '.dot'];
out=[pth '.pdf'];

f = fopen(in,'w') ; fwrite(f, str) ; fclose(f) ;

cmd = sprintf('"%s" -Tpdf %s -o %s', dotexe, in, out) ;
[status, result] = system(cmd) ;
if status ~= 0
  error('Unable to run %s\n%s', cmd, result);
end
fprintf('Dot output:\n%s\n', result);

%f = fopen(out,'r') ; file=fread(f, 'char=>char')' ; fclose(f) ;
switch computer
  case 'MACI64'
    system(sprintf('open "%s"', out)) ;
  case 'GLNXA64'
    system(sprintf('display "%s"', out)) ;
  otherwise
    fprintf('PDF figure saved at "%s"\n', out) ;
end

