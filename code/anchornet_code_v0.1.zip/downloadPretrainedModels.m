function downloadPretrainedModels()

	[dataDir,imagenetDir] = setupPaths();

	classes = { 'car','bicycle','aeroplane', 'bird', 'boat', 'bottle', 'bus', ...
			    'cat', 'chair', 'cow', 'dining table', 'dog', 'horse', ...
			    'motorbike',  'potted plant', 'sheep', 'sofa', 'train', 'tvmonitor','person' } ; 
	classes = sort(classes);
	disp(classes);

	% download class-spec models
	for clsi = 1:numel(classes)
		cls_  = classes{clsi};
		cls__ = strrep(cls_,' ','_');
		tgtDir = fullfile(dataDir,sprintf('001-classSpecificFilters-%s',cls__));
		url_ = fullfile('http://www.robots.ox.ac.uk/~david/anchornet',sprintf('class-spec-%s.mat',cls__));
		tgtFile = fullfile(tgtDir,'net-epoch-1.mat');
		vl_xmkdir(tgtDir);
		fprintf('fetching the %s class-specific model from %s into %s\n',cls_,url_,tgtFile);
		urlwrite(url_,tgtFile);
	end

	% download the class-agno model
	tgtDir = fullfile(dataDir,'001-classAgnosticFilters');
	url_ = fullfile('http://www.robots.ox.ac.uk/~david/anchornet','class-agnostic.mat');
	vl_xmkdir(tgtDir);
	tgtFile = fullfile(tgtDir,'net-epoch-6.mat');
	vl_xmkdir(tgtDir);
	fprintf('fetching the class-agnostic model from %s into %s\n',url_,tgtFile);
	urlwrite(url_,tgtFile);

end