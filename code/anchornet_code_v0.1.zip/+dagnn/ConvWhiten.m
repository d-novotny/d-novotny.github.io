classdef ConvWhiten < dagnn.Filter
  properties
    size = [0 0 0 0]
    hasBias = true
    whtStrength = 0
    opts = {'cuDNN'}
    nrm = false
    p = 2
    whitengroups = [];
    nrmFull = false;
    fixGroups = false;
  end

  properties (Transient)
    average = 0
    numAveraged = 0
    averageNrm = 0
  end

  methods
    
    function outputs = forward(obj, inputs, params)

      if ~obj.hasBias, params{2} = [] ; end
      
      p1 = params{1};
    
      outputs{1} = vl_nnconv( inputs{1}, p1, params{2}, 'pad', obj.pad, 'stride', obj.stride, 'dilate', obj.dilate, obj.opts{:}) ;

      if obj.whtStrength ~= 0
        wht_ = vl_nnwhiten(p1,[],'p',obj.p,'nrm',obj.nrm,'groups',obj.whitengroups,'nrmFull',obj.nrmFull,'fixGroups',obj.fixGroups);
        nrm_ = (p1(:)'*p1(:)) / size(p1,4);
      else
        wht_ = 0; nrm_ = 0;
      end

      n = obj.numAveraged ;
      m = n + 1 ;
      obj.average = (n * obj.average + gather(wht_)) / m ;
      obj.averageNrm = (n * obj.average + gather(nrm_)) / m ;
      obj.numAveraged = m ;

    end

    function [derInputs, derParams] = backward(obj, inputs, params, derOutputs)
      
      p1 = params{1};

      if ~obj.hasBias, params{2} = [] ; end
      [derInputs{1}, dp1, derParams{2}] = vl_nnconv(...
        inputs{1}, p1, params{2}, derOutputs{1}, ...
        'pad', obj.pad, ...
        'stride', obj.stride, ...
        'dilate', obj.dilate, ...
        obj.opts{:}) ; 

      if obj.whtStrength ~= 0 
        g = vl_nnwhiten(p1,obj.whtStrength,'p',obj.p,'nrm',obj.nrm,'groups',obj.whitengroups,'nrmFull',obj.nrmFull,'fixGroups',obj.fixGroups);
        dp1 = dp1 + g;
      end

      derParams{1} = dp1;

    end

    function kernelSize = getKernelSize(obj)
      kernelSize = obj.size(1:2) ;
    end

    function outputSizes = getOutputSizes(obj, inputSizes)
      outputSizes = getOutputSizes@dagnn.Filter(obj, inputSizes) ;
      outputSizes{1}(3) = obj.size(4) ;
    end

    function params = initParams(obj)
      sc = sqrt(2 / prod(obj.size(1:3))) ;
      params{1} = randn(obj.size,'single') * sc ;
      if obj.hasBias
        params{2} = zeros(obj.size(4),1,'single') * sc ;
      end
    end

    function set.size(obj, ksize)
      % make sure that ksize has 4 dimensions
      ksize = [ksize(:)' 1 1 1 1] ;
      obj.size = ksize(1:4) ;
    end

    function obj = ConvWhiten(varargin)
      obj.load(varargin) ;
      % normalize field by implicitly calling setters defined in
      % dagnn.Filter and here
      obj.size = obj.size ;
      obj.stride = obj.stride ;
      obj.pad = obj.pad ;
      obj.whtStrength = obj.whtStrength;
      obj.p = obj.p;
      obj.nrm = obj.nrm;
    end

    function reset(obj)
      obj.average = 0 ;
      obj.numAveraged = 0 ;
      obj.averageNrm = 0 ;
    end

  end
end
