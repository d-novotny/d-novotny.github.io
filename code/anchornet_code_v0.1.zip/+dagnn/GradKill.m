classdef GradKill < dagnn.ElementWise

  properties
    fac = 1;
    thr = inf;
  end

  methods
    function outputs = forward(self, inputs, params)

      outputs{1} = inputs{1};
      if isfinite(self.thr)
        error();
        mask = inputs{1} > self.thr;
        outputs{1}(mask) = self.thr; 
      end

    end

    function [derInputs, derParams] = backward(self, inputs, params, derOutputs)
      derInputs = derOutputs;
      for ii = 1:numel(derInputs)
        derInputs{ii} = derInputs{ii}*self.fac;
        if isfinite(self.thr)
          error(); 
          mask = inputs{ii} > self.thr;
          derInputs{ii}(mask) = 0;
        end
      end
      derParams = {};
    end

    function obj = GradKill(varargin)
      obj.load(varargin) ;
    end
  end
end
