classdef LayerDistWeightedC2 < dagnn.Loss
  properties
    p = 2
    c = -1
    normByNPix = true;
    border = 0;
  end

  methods
    function outputs = forward(obj, inputs, params)
      
      %inputs{1} % original map
      %inputs{2} % sampled map
      %inputs{3} % weights for in1
      %inputs{4} % weights for in2
    
      ign = ~isfinite(inputs{2}) | ~isfinite(inputs{1});
      inputs{1}(ign) = 0;
      inputs{2}(ign) = 0;

      d = obj.getLoss_(inputs);
      wmap = obj.getWMap(inputs,d);

      d = bsxfun(@times,d,wmap);
      if obj.c>0
        d(wmap==0) = abs(obj.c)^obj.p; 
      end
      outputs{2} = d;

      d = sum(d(:));

      if false && rand() > 0.9
        nDim = size(inputs{1},3);
        show_ = 1:10:nDim;
        figure(1); clf;
        for di=1:numel(show_)
          vl_tightsubplot(2,numel(show_),di);
          imagesc(gather(inputs{1}(:,:,di,1)));
          vl_tightsubplot(2,numel(show_),di+numel(show_));
          imagesc(gather(inputs{2}(:,:,di,1)));
        end
        drawnow;
      end

      if obj.normByNPix
        denom = 1/(size(wmap,1)*size(wmap,2));
        d = d*denom;
      end
      outputs{1} = d;


      n = obj.numAveraged ;
      m = n + size(inputs{1},4) ;
      obj.average = (n * obj.average + gather(sum(outputs{1}(:)))) / m ;
      obj.numAveraged = m ;

    end

    function [derInputs, derParams] = backward(obj, inputs, params, derOutputs)
      
      ign = ~isfinite(inputs{2}) | ~isfinite(inputs{1});
      inputs{1}(ign) = 0;
      inputs{2}(ign) = 0;

      d    = obj.getLoss_(inputs);
      wmap = obj.getWMap(inputs,d);
      % d    = bsxfun(@times,d,wmap);

      switch obj.loss
        case 'l2'
          do = bsxfun(@times,wmap,derOutputs{1});
          [derInputs{1},derInputs{2}] = vl_nnpdist(inputs{1}, inputs{2}, obj.p, do, 'aggregate', false, 'noRoot', true);
        case 'revhu'
          error()
          [derInputs{1},derInputs{2}]  = vl_nnreversehuber(inputs{1}, inputs{2}, obj.getC(inputs), derOutputs{1});
          % derInputs{1} = sum(derInputs{1},3);
          % derInputs{2} = sum(derInputs{2},3);
        case 'dot'
          error()
          derInputs{1} = -bsxfun(@times,inputs{2},derOutputs{1});
          derInputs{2} = -bsxfun(@times,inputs{1},derOutputs{1});
        otherwise
          error('no such loss %s',obj.distFunc); 
      end

      denom = 1/(size(wmap,1)*size(wmap,2));

      if numel(inputs)==3
        assert(obj.c < 0);
        derInputs{3} = bsxfun(@times,d,derOutputs{1});
        if obj.border>0
          derInputs{3} = obj.killBorder(derInputs{3},obj.border);
        end
        if obj.normByNPix
          derInputs{3} = derInputs{3}*denom;
        end
        % derInputs{3} = derInputs{3}*0.1;

        % for ii = 3:3
        %   derInputs{ii} = inputs{ii-2}(:,:,1,:);
        %   derInputs{ii}(:) = 0;
        %   if obj.normByNPix
        %     derInputs{ii} = derInputs{ii}*denom;
        %   end
        % end
      end

      for ii = 1:2
        % derInputs{ii} = bsxfun(@times,derInputs{ii},wmap);
        if obj.normByNPix
          derInputs{ii} = derInputs{ii}*denom;
        end
      end

      derParams = {};


      % disp(sum(derInputs{3}(:)));

    end

    function d = getLoss_(obj,inputs)

      assert(strcmp(obj.loss,'l2'));

      switch obj.loss
        case 'l2'
          [d] = vl_nnpdist(inputs{1}, inputs{2}, obj.p, 'aggregate', false, 'noRoot', true);
        case 'revhu'
          error('todo ...')
          [d] = vl_nnreversehuber(inputs{1}, inputs{2 }, obj.getC(inputs), []);
        case 'tukey'
          error('todo ...')
          [d] = vl_nnreversehuber(inputs{1}, inputs{2 }, obj.getC(inputs), []);
        case 'dot'
          d = -sum(inputs{1}.*inputs{2},3); 
        otherwise
          error('no such loss %s',obj.distFunc);
      end

    end



    function wmap = getWMap(obj,inputs,d)

      if numel(inputs)==3
        wmap = inputs{3};
      elseif numel(inputs)==2
        wmap = ones(size(inputs{1},1),size(inputs{1},2),1,size(inputs{1},4),'single');
        if isa(inputs{1},'gpuArray')
          wmap = gpuArray(wmap);
        end
      else
        error('wrong n inputs');
      end
      if obj.border>0
        wmap = obj.killBorder(wmap,obj.border);
      end
      if obj.c > 0
        wmap(abs(d)>obj.c^obj.p) = 0;
      end

      
    end

    % function f = map2feats(m)
    %   f = permute(m,[3 1 2]);
    %   f = reshape(f,[size(f,1) size(f,2)*size(f,3)]);
    % end

    function v = killBorder(obj,v,b)

        absBorder = ceil([size(v,1) size(v,2)]*b); 
        % disp(absBorder)
        ok = v; ok(:) = 0;
        ok((absBorder(1)+1):(end-absBorder(1)),(absBorder(2)+1):(end-absBorder(2)),:,:) = 1;
        v = bsxfun(@times,v,ok);
      
    end

    function obj = LayerDistWeightedC2(varargin)
      obj.load(varargin) ;
    end
  end
end
