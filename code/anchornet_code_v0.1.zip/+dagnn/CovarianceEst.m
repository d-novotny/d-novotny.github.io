classdef CovarianceEst < dagnn.ElementWise
  
  properties(Transient)
    mu1 = 0;
    M12 = 0;
    N = 0;
    updateDiff = 0;
    cv = 0
  end

  methods
    function outputs = forward(obj, inputs, params)

      % idx = randi([1,size(x,2)]);
      % x_  = x(:,idx);
      
      nSamples = 1e2;

      % nSamples = size(inputs{1},4);
      % nPix     = size(inputs{1},2)*size(inputs{1},1);

      prevM12 = obj.M12;

      % x_ = squeeze(inputs{1}(:,:,:,:));
      x_ = permute(inputs{1},[3 1 2 4]);
      x_ = reshape(x_, size(x_,1), size(x_,3)*size(x_,2)*size(x_,4) );

      if size(x_,2)~=nSamples
        sel = randi([1,size(x_,2)],1,nSamples);
        x_  = x_(:,sel);
      end

      for smpli = 1:size(x_,2)
          d1  = (x_(:,smpli) - obj.mu1) / (obj.N+1) ;
          obj.mu1 = obj.mu1 + d1 ;
          obj.M12 = obj.M12 + (obj.N*d1)*d1' - obj.M12/(obj.N+1);
          obj.N = obj.N+1;
      end

      df = norm(obj.M12(:)-prevM12(:),'fro');

      % fprintf('Cov matrix update norm = %1.2e\n',df);

      obj.updateDiff = df;

      outputs{1} = obj.mu1;
      outputs{2} = obj.N/(obj.N-1) * obj.M12;

      obj.cv = outputs{2}; 

      % disp(outputs{2})

    end

    function reset(obj)
      obj.mu1 = 0 ;
      obj.M12 = 0 ;
      obj.updateDiff = 0;
      obj.N = 0; 
      obj.cv = 0;
    end

    function [derInputs, derParams] = backward(obj, inputs, params, derOutputs)
      derInputs{1} = 0;
      derParams = [];
    end

    function obj = CovarianceEst(varargin)
      obj.load(varargin{:}) ;
    end


    function outputSizes = getOutputSizes(obj, inputSizes, paramSizes)
      for ii=1:2
        outputSizes{ii} = NaN*ones(1,4) ;
      end
    end

    function rfs = getReceptiveFields(obj)
      % the receptive field depends on the dimension of the variables
      % which is not known until the network is run
      for ii=1
        for jj=1:2 
          rfs(ii,jj).size = [NaN NaN] ;
          rfs(ii,jj).stride = [NaN NaN] ;
          rfs(ii,jj).offset = [NaN NaN] ; 
        end
      end 
    end


  end
end