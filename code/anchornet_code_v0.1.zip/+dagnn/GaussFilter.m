classdef GaussFilter < dagnn.ElementWise
  
  properties
    flt = {};
    preserveMode = false;
    nanFilter = false;
    opts = {'cuDNN'}
  end

  methods

    function outputs = forward(obj, inputs, params)

      if obj.preserveMode
        error();
        outputs{1} = vl_nngaussmodefilter(inputs{1},obj.flt,[]);
      elseif obj.nanFilter
        outputs{1} = vl_nngaussnanfilter(inputs{1},obj.flt,[]);
      else
        outputs{1} = vl_nngaussfilter(inputs{1},obj.flt,[]);
      end 

    end

    function [derInputs, derParams] = backward(obj, inputs, params, derOutputs) 

      if obj.preserveMode
        error();
        derInputs{1} = vl_nngaussmodefilter(inputs{1},obj.flt,derOutputs{1});
      elseif obj.nanFilter
        derInputs{1} = vl_nngaussnanfilter(inputs{1},obj.flt,derOutputs{1}); 
      else
        derInputs{1} = vl_nngaussfilter(inputs{1},obj.flt,derOutputs{1});
      end

      derParams = {};

    end

    function move(obj, device)
    
      switch device
        
        case 'cpu'
          flt_ = {};
          for flti = 1:numel(obj.flt)
            flt_{flti} = gather(obj.flt{flti});
          end
          obj.flt = flt_;
          
        case 'gpu'
          flt_ = {};
          for flti = 1:numel(obj.flt)
            flt_{flti} = gpuArray(obj.flt{flti});
          end
          obj.flt = flt_; 
        
        otherwise
          error();

      end
    end

    function obj = GaussFilter(varargin)
      obj.load(varargin) ;
    end

  end
end
