classdef GlobNorm < dagnn.ElementWise
  properties
    epsilon = 1e-2 ;
    p = 2 ;
    multByNPix = false;
  end

  methods
    function outputs = forward(obj, inputs, params)

      d_ = inputs{1};
      npix = size(d_,1)*size(d_,2);
      d_ = reshape(d_,1,1,size(d_,1)*size(d_,2)*size(d_,3),size(d_,4)); 

      d_ = vl_nnnormalizelp(d_,[],'epsilon', obj.epsilon, 'p', obj.p) ; %* npix ;
      if obj.multByNPix
        error();
        d_ = d_*npix;
      end

      outputs{1} = reshape(d_,size(inputs{1}));

    end

    function [derInputs, derParams] = backward(obj, inputs, param, derOutputs)

      d_ = inputs{1};
      npix = size(d_,1)*size(d_,2);
      d_ = reshape(d_,1,1,size(d_,1)*size(d_,2)*size(d_,3),size(d_,4));
      dd_ = derOutputs{1};
      dd_ = reshape(dd_,1,1,size(dd_,1)*size(dd_,2)*size(dd_,3),size(dd_,4));
      if obj.multByNPix
        error();
        dd_ = dd_*npix;
      end
      d_ = vl_nnnormalizelp(d_, dd_, 'epsilon', obj.epsilon, 'p', obj.p) ; %* npix ; 

      derInputs{1} = reshape(d_,size(inputs{1}));
      derParams = {} ;

    end

    function obj = GlobNorm(varargin)
      obj.load(varargin) ;
    end
  end
end