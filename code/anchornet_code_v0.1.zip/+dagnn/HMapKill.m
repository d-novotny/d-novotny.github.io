classdef HMapKill < dagnn.ElementWise

  properties
    rate = 0.5;
  end

  properties (Transient)
    mask
  end

  methods
    function outputs = forward(self, inputs, params)

      if strcmp(self.net.mode, 'test')
        outputs = inputs ;
        return ;
      end

      mask = rand(1,1,size(inputs{1},3),size(inputs{1},4));
      mask = single(mask > self.rate);
      self.mask = mask;

      outputs{1} = bsxfun(@times,inputs{1},mask);

      
    end

    function [derInputs, derParams] = backward(self, inputs, params, derOutputs)  

      if strcmp(self.net.mode, 'test')
        derInputs = derOutputs ;
        derParams = {} ;
        return ;
      end

      derInputs{1} = bsxfun(@times,derOutputs{1},self.mask);
      derParams = {};
    
    end

    function obj = HMapKill(varargin)
      obj.load(varargin) ;
    end
  end
end
