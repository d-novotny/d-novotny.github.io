classdef ConvBias < dagnn.ElementWise
  methods
    function outputs = forward(obj, inputs, params)
      outputs{1} = bsxfun(@minus,inputs{1},params{1}); 
    end

    function [derInputs, derParams] = backward(obj, inputs, params, derOutputs)
      nPix = (size(inputs{1},1)*size(inputs{1},2));
      derInputs = derOutputs;
      derP = sum(sum(sum(inputs{1},1),2),4)/nPix;
      derParams = {derP};
    end

    function outputSizes = getOutputSizes(obj, inputSizes, paramSizes)
      outputSizes{1} = inputSizes{1} ;
    end

    function rfs = getReceptiveFields(obj)
      % the receptive field depends on the dimension of the variables
      % which is not known until the network is run
      rfs(1,1).size = [NaN NaN] ;
      rfs(1,1).stride = [NaN NaN] ;
      rfs(1,1).offset = [NaN NaN] ;
    end

    function obj = ConvBias(varargin)
      obj.load(varargin) ;
    end
  end
end
