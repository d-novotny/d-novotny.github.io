classdef OnlyPositive < dagnn.ElementWise
  methods
    function outputs = forward(obj, inputs, params)
      outputs{1} = single(inputs{1}>0) ;
    end

    function [derInputs, derParams] = backward(obj, inputs, params, derOutputs)
    	derInputs{1} =  inputs{1}; derInputs{1}(:) = 0;
    	derParams = {};
    end
  end
end
