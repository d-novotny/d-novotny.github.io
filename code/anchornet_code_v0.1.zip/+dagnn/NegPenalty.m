classdef NegPenalty < dagnn.ElementWise
  
  properties
    max0 = true;
  end

  properties (Transient)
    average = 0
    numAveraged = 0
  end

  methods
    function outputs = forward(obj, inputs, params)
      
      neg = single(inputs{2}==-1);
      nPix = size(inputs{1},1)*size(inputs{1},2);  
      if obj.max0
        flt = max(inputs{1},0); 
      else
        error();
        flt = inputs{1};
      end
      flt = bsxfun(@times,flt,neg);
      outputs{1} = sum(flt(:))*(1/nPix);

      n = obj.numAveraged ;
      m = n + size(inputs{1},4) ;
      obj.average = (n * obj.average + gather(outputs{1})) / m ;
      obj.numAveraged = m ;

    end

    function [derInputs, derParams] = backward(obj, inputs, params, derOutputs)

   	  neg = single( inputs{2} == -1 );
      nPix = size(inputs{1},1)*size(inputs{1},2);
      if obj.max0
        mask = single(inputs{1} > 0);
      else
        error();
        mask = 1;
      end
      flt = inputs{1}; flt(:) = 1;
      flt = bsxfun(@times,flt,neg).*mask;
      flt = flt*(1/nPix); 

      % fprintf('neg %d; gnrm %1.2e\n',neg,norm(flt(:)));
      derInputs{1} = bsxfun(@times,flt,derOutputs{1});
      derInputs{2} = 0;
      derParams = {} ;
    
    end

    function obj = NegPenalty(varargin)
      obj.load(varargin);
    end

    function reset(obj)
      obj.average = 0 ;
      obj.numAveraged = 0 ;
    end

    function outputSizes = getOutputSizes(obj, inputSizes, paramSizes)
      outputSizes{1} = [1 1 1 inputSizes{1}(4)] ;
    end

    function rfs = getReceptiveFields(obj)
      % the receptive field depends on the dimension of the variables
      % which is not known until the network is run
      rfs(1,1).size = [NaN NaN] ;
      rfs(1,1).stride = [NaN NaN] ;
      rfs(1,1).offset = [NaN NaN] ;
      rfs(2,1) = rfs(1,1) ;
    end


  end
end
