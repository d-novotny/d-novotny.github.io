classdef SoftPlus < dagnn.ElementWise
  methods
    function outputs = forward(self, inputs, params)
      outputs{1} = vl_nnsoftplus(inputs{1},[]) ;
    end

    function [derInputs, derParams] = backward(self, inputs, params, derOutputs)
      derInputs{1} = vl_nnsoftplus(inputs{1}, derOutputs{1}) ;
      derParams = {} ;
    end

    function obj = SoftPlus(varargin)
      obj.load(varargin) ;
    end
  end
end
