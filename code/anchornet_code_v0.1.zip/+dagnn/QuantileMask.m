classdef QuantileMask < dagnn.ElementWise
  
  properties
    quantile = 1; % top quantile % 
    multiclass = false;
  end

  methods
    
    function outputs = forward(self, inputs, params)
      
      [appMask,geomMask] = self.getMask(inputs{1},inputs{2},self.quantile);

      outputs{1} = appMask;
      outputs{2} = geomMask; 

    end

    function [derInputs, derParams] = backward(self, inputs, params, derOutputs)      
      
      derO = inputs{1}; derO(:) = 0;
      derInputs{1} = derO;
      derInputs{2} = 0;
      derParams = {} ;
    
    end

    function [appMask,geomMask] = getMask(self,data,label,portion)

      nC = size(data,3);
      if self.multiclass
        nC = nC/numel(unique(self.net.meta.obClassMask));
        assert(round(nC)==nC); % has to be integral
      end

      posmask = label;
      posmask(posmask<=0) = -inf;
      data = bsxfun(@plus,data,posmask); % the order stays the same ...

      [sortVals,sortIdx] = sort(data,3,'descend');
      stop_ = round(nC*self.quantile); stop_ = min(stop_,size(data,3));

      levels = sortVals(:,:,stop_,:);
      ok = single(bsxfun(@ge,data,levels));
      if isa(data,'gpuArray')
        ok = gpuArray(ok);
      end

      appMask = ok;
      % neglab = 1-single(label==1);
      neglab = single(label<0);
      poslab = single(label>0);

      appMask  = bsxfun(@max,appMask,neglab);
      geomMask = bsxfun(@times,ok,poslab);

      % disp(any(appMask(:)==0));

    end

    function obj = QuantileMask(varargin)
      obj.load(varargin) ;
    end

  end
end
