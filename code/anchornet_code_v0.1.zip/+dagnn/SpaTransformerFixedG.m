classdef SpaTransformerFixedG < dagnn.Layer

  properties
    outSz = [0 0]
    midCrop = false;
  end

  methods
    function outputs = forward(obj, inputs, params)

      % inputs{1} ... fmap
      % inputs{2} ... pts

      sz = size(inputs{1});

      % disp(obj.getSelf());

      if all(sz(1:2)==obj.outSz)
        outputs{1} = inputs{1};
      else
        g = obj.getGrid(inputs);
        assert(numel(g)>0);
        assert(all(isfinite(g(:))));
        outputs{1} = vl_nnbilinearsampler(inputs{1},g);
      end

    end

    function grid = getGrid(obj,inputs)

      cellWidth = 2./obj.outSz;
      offs = cellWidth/2;

      if obj.midCrop
        error('wtf? dont use this');
        ygrid = single(linspace(-0.5+offs(1),0.5-offs(1),obj.outSz(1)));
        xgrid = single(linspace(-0.5+offs(2),0.5-offs(2),obj.outSz(2)));
      else
        ygrid = single(linspace(-1+offs(1),1-offs(1),obj.outSz(1)));
        xgrid = single(linspace(-1+offs(2),1-offs(2),obj.outSz(2)));
      end

      [xgrid,ygrid] = meshgrid(xgrid,ygrid);
      grid = cat(3,ygrid,xgrid);
      if isa(inputs{1},'gpuArray')
        grid = gpuArray(grid);
      end

      grid = permute(grid,[3 1 2]);
      grid = repmat(grid,[1 1 1 size(inputs{1},4)]);

    end

    function [derInputs, derParams] = backward(obj, inputs, param, derOutputs)
      sz = size(inputs{1});

      derParams = {};
      if numel(derOutputs{1})==1
        if derOutputs{1} == 0
          derInputs{1} = inputs{1};
          derInputs{1}(:) = 0;
          return;
        end 
      end

      if all(sz(1:2)==obj.outSz)
        derInputs{1} = derOutputs{1};
      else
        g = obj.getGrid(inputs);
        assert(numel(g)>0);
        [derInputs{1},~] = vl_nnbilinearsampler(inputs{1},g,derOutputs{1});
      end
      
    end


    function outputSizes = getOutputSizes(obj, inputSizes)
      xSize = inputSizes{1};
      gSize = obj.outSz(1:2); % inputSizes{2};
      outputSizes = {[gSize(1), gSize(2), xSize(3), xSize(4)]};
    end

    function obj = SpaTransformerFixedG(varargin)
      obj.load(varargin);
    end

  end

end