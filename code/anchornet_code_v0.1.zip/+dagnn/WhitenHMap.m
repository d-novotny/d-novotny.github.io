classdef WhitenHMap < dagnn.ElementWise

  properties (Transient)
    average = 0
    numAveraged = 0
  end

  methods

    function outputs = forward(self, inputs, params)
      
      if numel(inputs)==2
        ok  = single(inputs{2}==1);
        flt = bsxfun(@times,inputs{1},ok);
      elseif numel(inputs)==1
        flt = inputs{1};
        ok = ones(1,1,size(inputs{1},3),1);
      else
        error('cant');
      end

      wht = vl_nnwhitenhmap(flt,[],'nrm',true);
      outputs{1} = wht;

      nrmFac = numel(find(ok));

      n = self.numAveraged ;
      m = n + nrmFac ;
      self.average = (n * self.average + gather(outputs{1})) / max(m,1e-8) ;
      self.numAveraged = m ;

    end

    function [derInputs, derParams] = backward(self, inputs, params, derOutputs)

      if numel(inputs)==2
        ok  = single(inputs{2}==1);
        flt = bsxfun(@times,inputs{1},ok);
      elseif numel(inputs)==1
        flt = inputs{1};
        ok = 1;
      else
        error('cant');
      end

      derInputs{1} = vl_nnwhitenhmap(flt,derOutputs{1},'nrm',true);

      if numel(inputs)==2
        derInputs{1} = bsxfun(@times,derInputs{1},ok);
        derInputs{2} = 0; 
      end

      derParams = {} ;

    end

    function reset(obj)
      obj.average = 0 ;
      obj.numAveraged = 0 ;
    end

    function rfs = getReceptiveFields(obj)
      % the receptive field depends on the dimension of the variables
      % which is not known until the network is run
      rfs(1,1).size = [NaN NaN] ;
      rfs(1,1).stride = [NaN NaN] ;
      rfs(1,1).offset = [NaN NaN] ;
      rfs(2,1) = rfs(1,1) ;
    end

    function outputSizes = getOutputSizes(obj, inputSizes, paramSizes)
      outputSizes{1} = [1 1 1 inputSizes{1}(4)] ;
    end

    function obj = WhitenHMap(varargin)
      obj.load(varargin) ;
    end
  end
end
