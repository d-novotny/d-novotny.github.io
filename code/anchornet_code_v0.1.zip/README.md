# AnchorNet: A Weakly Supervised Network to Learn Geometry-sensitive Features For Semantic Matching
[David Novotny](http://www.robots.ox.ac.uk/~david/)
[Diane Larlus](http://www.europe.naverlabs.com/NAVER-LABS-Europe/People/Diane-Larlus)
[Andrea Vedaldi](http://www.robots.ox.ac.uk/~vedaldi/)

This readme file describes the source code for the following publication:
<i> Novotny, D., Larlus, D., Vedaldi, A.</i>: AnchorNet: A Weakly Supervised Network to Learn Geometry-sensitive Features For Semantic Matching, in CVPR 2017

# Code setup
1. Download and compile [matconvnet](http://www.vlfeat.org/matconvnet/)
2. Download and compile [vlfeat](http://www.vlfeat.org/)
3. Open `setupPaths.m` and set the `matconvnetPath` and `vlfeatPath` to point to the corresponding directories
4. In `setupPaths.m` set the `dataDir` string to point to the directory for experimental results (make sure there's at least 10 GB of free space)
(Optional: training code only)
5. Download [imagenet12](http://www.image-net.org/challenges/LSVRC/2012/) and in `setupPaths.m` set the `imagenetDir` string to point to the "images" directory of the ILSVRC12 dataset

# Training
1. run `experiments_stage1(1:20,GPU)`, where "GPU" stands for the index of the gpu used for training
2. after stage 1 finishes, run `experiments_stage2(1,GPU)`, where "GPU" stands for the index of the gpu used for training
If all the paths are setup correctly the training should finish without any problems
The first stage takes around 24h on a single TitanX GPU, second stage takes around 6 hours.

# Evaluation 
1. In case you haven't trained the models yourself, run `downloadPretrainedModels.m` . 
2. Run `runEval(1:2)` .

Again, if all the paths are correctly setup the evaluation should finish without problems. 
Note that the evaluation code takes around 24h even when heavily parallelized.