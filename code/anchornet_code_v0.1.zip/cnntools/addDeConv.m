function net = addDeConv(net,bottom,top,sz,pad,scale,lr,stride,hasBias)

	fname = [top '_f'];
	bname = [top '_b'];

	if hasBias
		prms = {fname,bname};
	else
		prms = {fname};
	end

	net.addLayer(top, dagnn.ConvTranspose('size', sz, 'crop', pad, 'upsample', stride, 'hasBias', hasBias), bottom, top, prms);

	f = net.getParamIndex(fname) ;
	net.params(f).value = randn(sz, 'single')*scale ;
	net.params(f).learningRate = lr ;
	net.params(f).weightDecay = 1 ;
	net.params(f).trainMethod = 'gradient'; 

	if hasBias
		f = net.getParamIndex(bname) ;
		net.params(f).value = zeros(sz(3), 1, 'single') ;
		net.params(f).learningRate = lr ;
		net.params(f).weightDecay = 1 ;
		net.params(f).trainMethod = 'gradient';
	end

end
