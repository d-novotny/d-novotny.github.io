function net = addWhiteningT(net,bot,top,filters,biases,lr)

	if nargin < 6
		lr = 1;
	end

	fead = size(filters,2);
	whtd = size(filters,1); 

	% if whtd ~= fead
	% 	keyboard
	% end

	fname = [top '_whtf'];
	bname = [top '_whtb'];

	net.addLayer(top, dagnn.Conv('size', [1 1 fead whtd], 'pad', 0, 'stride', 1), bot, top, {fname,bname});

	f = net.getParamIndex(fname) ;
	net.params(f).value = single(reshape(filters',[1 1 fead whtd])) ;
	net.params(f).learningRate = lr ;
	net.params(f).weightDecay = 1 ; 
	net.params(f).trainMethod = 'gradient'; 

	f = net.getParamIndex(bname) ;
	net.params(f).value = single(biases(:)); % single(reshape(biases(:),[1 1 1 whtd])) ;
	net.params(f).learningRate = lr ;
	net.params(f).weightDecay = 0 ;
	net.params(f).trainMethod = 'gradient';

end