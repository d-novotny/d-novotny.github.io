function [wht,t] = getWhiteningT(cv,mu,ndim,whiten)

	ndim = min(ndim,size(cv,1));

	cv = cv + eye(size(cv,1))*1e-8;

	tic
	[U,D] = eig(cv);   
	toc

	U = real(U);
	D = real(diag(D));

	[~,srtIdx] = sort(D,'descend');
	U = U(:,srtIdx(1:ndim));
	D = D(srtIdx(1:ndim));

	if whiten
		wht = diag(1./sqrt(D)) * U' ;
	else
		wht = real(U)';
	end

	t = -wht*mu ;

end