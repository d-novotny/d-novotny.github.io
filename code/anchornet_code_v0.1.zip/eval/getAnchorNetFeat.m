function [ feat, crop1, im_ ] = getAnchorNetFeat(opts,net,im1,box1)
 
    switch opts.netName
        case 'keypoints'
            predVar = net.getVarIndex('keyPointRelu');
        case 'ae256'
            predVar = net.getVarIndex('shareEncoder');
        otherwise
            error('no such net %s',opts.netName);
    end

    % fprintf('netname %s, predvar %s\n',opts.netName,net.vars(predVar).name);  
    
    netimsz = net.meta.normalization.imageSize(1:2);
    vszs    = net.getVarSizes( {'data',net.meta.normalization.imageSize} );
    outsz   = vszs{predVar};
   
    % if true
    %     figure(1); clf;
    %     subplot(1,2,1);
    %     imagesc(crop1);
    %     subplot(1,2,2);
    %     imagesc(im1);
    %     saveas(1,'~/junk/kpfDBG.png');
    %     keyboard 
    % end

    [crop1] = cropBoxIm(im1,box1(:));

    if opts.fullyConv
        sz_ = size(crop1);
        w = sz_(2); h = sz_(1);
        [net,origbsz,factor] = setSpaTSize(net,sz_,netimsz,[]);
        netim1 = imresize(crop1, ...
                         'scale', factor, ...
                         'method', 'bilinear') ;
    else
        netim1 = imresize(crop1,netimsz,'bilinear');
    end

    feat = {}; bnds = {};
  
    im_ = single(netim1);
 
    if size(im_,3)==1
        im_ = repmat(im_,[1 1 3]);
    end
    if ~isempty(net.meta.normalization.averageImage)
        avim = net.meta.normalization.averageImage;
        avim = imresize(avim,[size(netim1,1),size(netim1,2)],'bilinear');
        im_ = bsxfun(@minus,im_,avim);
    else
        error('avim should be always present!');
    end
    
    % run the CNN
    net.conserveMemory = true;
    net.mode = 'test'; % <---- important!!!
    if strcmp(net.device,'gpu')
        im_ = gpuArray(im_);
    end
 
    inputs = {'data', im_};
    net.eval(inputs) ;
    feat = net.vars(predVar).value;
    feat = gather(feat); 

    if opts.fullyConv
        [net] = setSpaTSize(net,sz_,netimsz,origbsz);
    end 

    if ~opts.rawFeats
        feat = imresize(feat, [size(crop1,1) size(crop1,2)], 'bilinear' );
    end
 
    if false % visualisation of feats
      offs = max(feat(:));
      kpmaps_ = offs+vl_imarray(feat(:,:,:)-offs,'spacing',2);
      figure(1); clf;
      vl_tightsubplot(3,1,1);
      imagesc(uint8(im1)); axis off; axis equal; axis tight; 
      vl_tightsubplot(3,1,2);  
      imagesc(kpmaps_); axis off;  axis equal; axis tight; colormap jet;
      vl_tightsubplot(3,1,3);
      imagesc(uint8(netim1)); axis off; axis equal; axis tight; 
      nm = 'feats';
      outfl = fullfile('/scratch/shared/slow/david/junk/anetdbg/',[nm '.png']);
      saveas(1,outfl); 
      disp(outfl); 
      keyboard 
    end

end

function [net,origbsz,factor] = setSpaTSize(net,imsz,netimsz,origbsz)

h = imsz(1); w = imsz(2);

ms = max([w h]);
assert(netimsz(1)==netimsz(2));
factor = netimsz(1)/ms;
% factor = min(factor) ;

recover = ~isempty(origbsz);
if ~recover
    origbsz = [];
end

is_ = find(cellfun(@isa,{net.layers(:).block},repmat({'dagnn.SpaTransformerFixedG'},1,numel(net.layers))));
for li = is_

    % fprintf('fixing size of layer %s\n',net.layers(li).name);

    b_ = net.layers(li).block;
    if recover
        % disp('recovering');
        % disp(b_.outSz);
        % disp(origbsz);
        b_.outSz = origbsz; 
        net.layers(li).block = b_;
    else
        if ~isempty(origbsz)
            assert(isequal(b_.outSz,origbsz));
        else
            origbsz = b_.outSz;
        end

        % fprintf('%d ', b_.outSz); fprintf(' -> ');

        if w < h
            b_.outSz = ceil([origbsz(1) origbsz(2)*(w/h)]); 
        elseif h < w
            b_.outSz = ceil([origbsz(1)*(h/w) origbsz(2)]);
        end
     
        % fprintf('%d ', b_.outSz); fprintf('\n'); 
        
        net.layers(li).block = b_;
    end
end

end

function [im1] = cropBoxIm(im1,box1e)

    padLeft  = abs(min(box1e(1)-1,0));
    padRight = max(box1e(3)-size(im1,2),0);
    padTop   = abs(min(box1e(2)-1,0));
    padBot   = max(box1e(4)-size(im1,1),0);

    im1 = padarray(im1,[padTop padLeft], 'pre' );
    im1 = padarray(im1,[padBot padRight],'post');

    box1e(1,:) = box1e(1,:)+padLeft;
    box1e(2,:) = box1e(2,:)+padTop;
    box1e(3,:) = box1e(3,:)+padLeft;
    box1e(4,:) = box1e(4,:)+padTop;

    im1 = im1(box1e(2):box1e(4),box1e(1):box1e(3),:);

end


