function net = loadAnchorNet(opts)

    if ~isempty(opts.gpu)
        gpuDevice(opts.gpu)  
    end
    disp(sprintf(opts.netPath));

    fprintf('netname %s\n',opts.netName);

    fprintf('netpath %s\n', opts.netPath);

    switch opts.netName

        case 'keypoints'

            fprintf('load of keypoints\n');
            net = load(opts.netPath);
            net = dagnn.DagNN.loadobj(net.net);
            net.mode = 'test';
            out = net.getVarIndex({'keyPointRelu'});
            net.vars(out).precious = true;

            if opts.normKeypoints   
                fprintf('kpnorm ...\n');
                net.renameVar('keyPointRelu','keyPointReluNoNrm');
                net.addLayer('keyPointReluNrm',dagnn.LPNorm, 'keyPointReluNoNrm', 'keyPointRelu' );
            end

        case 'ae256'

            fprintf('load of ae256\n');

            net      = load(opts.netPath);
            net      = dagnn.DagNN.loadobj(net.net);
            net.mode = 'test' ;

            out                    = net.getVarIndex({'shareEncoder'});
            net.vars(out).precious = true; 

            if opts.normKeypoints   
                fprintf('kpnorm ...\n');
                net.renameVar('shareEncoder','shareEncoderNoNrm');
                net.addLayer('shareEncoderNrm',dagnn.LPNorm, 'shareEncoderNoNrm', 'shareEncoder' );
            end

        otherwise
            error('no such netname %s',opts.netName);
    
    end

    rng(0,'twister');

    if ~isempty(opts.gpu)
        net.move('gpu');
    end

end
