function evalFlowWebDataset(varargin)

	opts.classes = { 'bicycle','aeroplane', 'bird', 'boat', 'bottle', 'bus', ...
				    'car','cat', 'chair', 'cow', 'table', 'dog', 'horse', ...
				    'motorbike',  'pottedplant', 'sheep', 'sofa', 'train', ...
				    'tvmonitor','person' };
	opts.resultDir = '/dev/null';
	opts.datasetRootDir = '';
	opts.netPath = '';
	opts.netName = '';
	opts.normKeypoints = false;
	opts.fullyConv = true; 
	opts.rawFeats = false;
	opts.flowsFunc = [];
	opts.featRescale = 100;
	opts.gpu = [];
	opts = vl_argparse(opts,varargin);

	vl_xmkdir(opts.resultDir);
	assert(exist(opts.resultDir)==7);

	% point to the dir with actual data
	opts.datasetDir = fullfile(opts.datasetRootDir,'pascal','data');
	imgdirs_ = dir(fullfile(opts.datasetDir,'*_set_*'));
	imgdirs_ = {imgdirs_(:).name};

	if isempty(imgdirs_) % download the dataset

		dataset_url = 'http://www.eecs.berkeley.edu/~tinghuiz/data/pascal_data.tar.gz' ;
		fprintf('downloading the flowweb dataset from %s\n',dataset_url) ;
		vl_xmkdir(opts.datasetRootDir);
		arch_file = fullfile(opts.datasetRootDir,'pascal_data.tar.gz');

		% urlwrite strangely makes an empty file -> good old wget way, apologies to win users
		cmd_wget  = sprintf('wget -O %s %s',arch_file,dataset_url);
		system(cmd_wget); % urlwrite( dataset_url, arch_file ) ;

		% untar fails too -> linux way again
		cmd_tar  = sprintf('tar -xvf %s -C %s',arch_file,opts.datasetRootDir); 
		system(cmd_tar); % untar( arch_file, opts.datasetRootDir ) ;

		% rescan the dataset folder
		imgdirs_ = dir(fullfile(opts.datasetDir,'*_set_*'));
		imgdirs_ = {imgdirs_(:).name};

	end

	rng(0,'twister'); 

	opts.classes = sort(opts.classes(:)');

	RESULTS = {};
	RESULTS_FIELDS = {'class','setid','metric','alpha','result'};  

	for class_ = opts.classes

		class_ = class_{1};

		nsets__ = nClassSets(class_);

		thisMean = [0;0];
		for setid = 1:nsets__

			imgset_  = [class_, '_set_' num2str(setid)];
			imgDir_  = fullfile(opts.datasetDir,imgset_);

			if ~ismember(imgset_,imgdirs_)
				error('cant happen!');
			end

			resultspath_ = fullfile(opts.resultDir,sprintf('%s-results_.mat',imgset_)); 

			if exist(resultspath_)==2 %&& false
				dt = load(resultspath_);
				results_thisset = dt.results_thisset;
				fprintf('%15s-%d iou %1.2f ; pck@0.05 %1.2f\n',results_thisset{4}{1},results_thisset{4}{2},results_thisset{4}{5},results_thisset{1}{5});
			else  
				results_thisset = extractResults(opts,resultspath_,imgDir_, class_, setid );
			end

			thisMean = thisMean + [results_thisset{4}{5};results_thisset{1}{5}];

			RESULTS = cat(1,RESULTS,results_thisset(:));
		end
		thisMean = thisMean/nsets__;

		fprintf('%30s - iou %1.2f ; pck@0.05 %1.2f\n\n',class_,thisMean(1),thisMean(2) );

	end    

	RESULTS = cat(1,RESULTS{:});

	showResults(opts,RESULTS);

end


function results_thisset = extractResults( opts, resultspath_, imgDir_, class_, setid )

	results_thisset = [];

	if ~isempty(strfind(opts.netPath,'%s'))
		classuniv = convertClassToPascal(class_);
		netpathnew_ = sprintf(opts.netPath,classuniv);
		netpathnew_ = strrep(netpathnew_,' ','_');
		fprintf('adjusting network path \n    %s\n      -> %s\n',opts.netPath,netpathnew_);
		opts.netPath = netpathnew_;
		if exist(netpathnew_)~=2
			fprintf('no %s\n',netpathnew_);
		end
	end	

	[ims] = loadImageSetUint8(imgDir_);
	[~,imgset,~] = fileparts(imgDir_);
	assert(single(nSetIms(imgset))/2==numel(ims));
	fprintf('assert ok\n');

	fprintf('%s - %s\n', opts.resultDir,imgset);

	results_thisset = {};

	[pairvx, pairvy] = opts.flowsFunc(opts, ims, imgset);

	% Evaluation
	results_thisset = {};
	for metric_ = {'keypoint','part'}

		metric = metric_{1}; % can also be 'part'
		evalParams = struct();
		evalParams.metric    = metric;
		evalParams.annoDir   = imgDir_;
		evalParams.resultDir = opts.resultDir;
		evalParams.imgset    = imgset;

		switch metric
			case 'keypoint'
				for aph = [0.05 0.1 0.2]
					evalParams.alpha = aph;
					[resInit,resAllInit] = evaluateFlows(evalParams);
					results_thisset{end+1} = {class_,setid,metric,aph,resInit,resAllInit,evalParams};
					fprintf('class = %s,  metric = %s, aph = %1.3f ', imgset, metric, aph);
					fprintf('   -> %3.3f\n', resInit);
				end
			case 'part'
				[resInit,resAllInit] = evaluateFlows(evalParams);
				results_thisset{end+1} = {class_,setid,metric,NaN,resInit,resAllInit,evalParams};
				fprintf('class = %s,  metric = %s ', class_, setid, metric); 
				fprintf('   -> %3.3f\n', resInit);
			otherwise
				error('cant be'); 
		end

	end % exist results
   
	fprintf('saving results to %s\n',resultspath_);
	save(resultspath_,'results_thisset');

end


function showResults(opts,RESULTS)

	% show nice results
	r_aphs = cat(1,RESULTS{:,4});
	r_classes = RESULTS(:,1);
	for metric_ = {'part','keypoint'}
		if strcmp(metric_{1},'keypoint')
			aphs = [0.05];  % 0.1 0.2];
		else
			aphs = NaN;
		end

		for aph = aphs

			allmean = 0; allmeanN = 0;
			meanstr = '';
			
			for class_ = opts.classes
				if isnan(aph)
					ok_ = isnan(r_aphs) & strcmp(r_classes,class_{1});
				else
					ok_ = r_aphs == aph & strcmp(r_classes,class_{1});
				end
				ris = find(ok_);
				meanmetric = mean(cat(1,RESULTS{ok_,5}));
				meanstr    = sprintf('%s%s %1.3f %15s %3.5f\n', meanstr,metric_{1},aph,class_{1},meanmetric);
				
				if ~isnan(meanmetric)
					allmean  = allmean + meanmetric;
					allmeanN = allmeanN + 1;
				end
			end
			
			fprintf('----\n');
			fprintf(meanstr);
			fprintf('----\n');

			allmean = allmean/allmeanN;
			fprintf('MEAN %3.6f\n',allmean);
					
		end
	end

end

function [n,nall] = nClassSets(cls)

	map_ = containers.Map;
	map_('aeroplane') = 3;
	map_('bicycle') = 3;
	map_('bird') = 2;
	map_('boat') = 2;
	map_('bottle') = 1;
	map_('bus') = 3;
	map_('car') = 3;
	map_('cat') = 2;
	map_('chair') = 2;
	map_('cow') = 3;
	map_('dog') = 2;
	map_('horse') = 3;
	map_('motorbike') = 3;
	map_('person') = 3;
	map_('pottedplant') = 1;
	map_('sheep') = 3;
	map_('sofa') = 2;
	map_('table') = 1;
	map_('train') = 3;
	map_('tvmonitor') = 2;

	assert(map_.Count==20);

	n = map_(cls);

	sets_ = {...
			'aeroplane_set_1', ...
			'aeroplane_set_2', ...
			'aeroplane_set_3', ...
			'bicycle_set_1', ...
			'bicycle_set_2', ...
			'bicycle_set_3', ...
			'bird_set_1', ...
			'bird_set_2', ...
			'boat_set_1', ...
			'boat_set_2', ...
			'bottle_set_1', ...
			'bus_set_1', ...
			'bus_set_2', ...
			'bus_set_3', ...
			'car_set_1', ...
			'car_set_2', ...
			'car_set_3', ...
			'cat_set_1', ...
			'cat_set_2', ...
			'chair_set_1', ...
			'chair_set_2', ...
			'cow_set_1', ...
			'cow_set_2', ...
			'cow_set_3', ...
			'dog_set_1', ...
			'dog_set_2', ...
			'horse_set_1', ...
			'horse_set_2', ...
			'horse_set_3', ...
			'motorbike_set_1', ...
			'motorbike_set_2', ...
			'motorbike_set_3', ...
			'person_set_1', ...
			'person_set_2', ...
			'person_set_3', ...
			'pottedplant_set_1', ...
			'sheep_set_1', ...
			'sheep_set_2', ...
			'sheep_set_3', ...
			'sofa_set_1', ...
			'sofa_set_2', ...
			'table_set_1', ...
			'train_set_1', ...
			'train_set_2', ...
			'train_set_3', ...
			'tvmonitor_set_1', ...
			'tvmonitor_set_2', ...
			};

	nall = numel(sets_);

end