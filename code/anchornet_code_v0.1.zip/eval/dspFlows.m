function [pairvx, pairvy] = dspFlows(opts, ims, imgset)

    N = length(ims);
    assert(N==numel(ims)); 

    flowsPath = fullfile(opts.resultDir,sprintf('%s-pairflows.mat',imgset) );
    fprintf('extracting flows %s\n',flowsPath);
    if exist(flowsPath, 'file')
        dt = load(flowsPath);
        pairvx = dt.pairvx;
        pairvy = dt.pairvy;  
        return;
    end

    if isempty(opts.netPath)
        assert(strcmp(opts.netName,'hog'));
        fprintf('extractig hog features ...\n');
        net = [];
    else
        assert(opts.normKeypoints,'not norming doesnt work!'); 
        assert(opts.featRescale==100,'feature rescaling should be 100!');  
        fprintf('loading network...\n');
        if ~isempty(opts.gpu)
            fprintf('resetting gpu %d ... \n',opts.gpu);
            gpuDevice(opts.gpu)
        end
        net = loadAnchorNet(opts);
        fprintf('Done\n');
    end

    pairvx = cell(N,N);
    pairvy = cell(N,N);
    feats  = cell(1, N); 

    for i = 1 : N  

        if isempty(net)
            feat_ = ExtractSIFT_WithPadding(ims{i}, [], 4);
            feats{i} = feat_;
        else
            feat_ = getAnchorNetFeat(opts,net,ims{i},[1 1 size(ims{i},2) size(ims{i},1)]);
            feat_ = feat_ * opts.featRescale; 
            feats{i} = feat_; 
            assert(size(feat_,3)<= 768, 'we dont use high dim features! -> dsp doesnt converge then ...');
        end

        if mod(i,15)==1
            fprintf('Extracting feats %5d/%5d (dim %d)\n',i,N,size(feat_,3));
        end
    end

    try
        f__ = cat(4,feats{:});
        fprintf('featsize = %d %d %d\n',size(feats{1},1),size(feats{1},2),size(feats{1},3));
        clear f__;
    catch
        error('bad features');
    end 

    dspOpts = struct();
    dspOpts.deformCoeff = 1;
    dspOpts.pixDeformCoeff = 1;

    for ii = 1 : N
        if mod(ii,15)==1
            fprintf('matching %5d/%5d\n', ii, N);
        end
        parfor jj = 1 : N  
            if ii == jj
                continue;
            end 
            [pairvx{ii,jj}, pairvy{ii,jj}] = DSPMatchKP(feats{ii}, feats{jj}, dspOpts.deformCoeff, dspOpts.pixDeformCoeff);
            pairvx{ii,jj} = single(pairvx{ii,jj});
            pairvy{ii,jj} = single(pairvy{ii,jj});
        end  
    end

    save(flowsPath, 'pairvx', 'pairvy');

end