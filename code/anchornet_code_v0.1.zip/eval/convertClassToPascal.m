function classout = convertClassToPascal(classin)

map = containers.Map;

pasclss = ...
		{...
		'aeroplane', 'bicycle', 'bird', 'boat', 'bottle', 'bus', ...
		'car', 'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse', ...
		'motorbike', 'person', 'potted plant', 'sheep', 'sofa', 'train', 'tvmonitor', };

for pascls = pasclss

    map(pascls{1}) = pascls{1};

end

map('table') = 'dining table';
map('dining table') = 'dining table';
map('diningtable') = 'dining table';
map('pottedplant') = 'potted plant';
map('tv') = 'tvmonitor';

classout = map(classin);

end

