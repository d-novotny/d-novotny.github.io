function [Y] = vl_nnwhiten(X,dzdy,varargin)

opts.p = 2;
opts.nrm = false;
opts.nrmFull = false;
opts.groups = [];
opts.fixGroups = false; 
opts = vl_argparse(opts,varargin) ;

wSize = size(X) ;

assert(wSize(4)>1);

if ~isempty(opts.groups)

  g1 = single(opts.groups);
  if isa(X,'gpuArray')
    g1 = gpuArray(g1);
  end
  maxg = max(g1(:))+1;
  if opts.fixGroups
    g2 = maxg*g1+g1;
    G = bsxfun(@plus,g1(:),g2(:)');
    okg = unique(diag(G));
    G = single(ismember(G,okg));
  else
    g2 = maxg+g1;
    okg = unique(g1.*g2);
    G = g1(:)*(g2(:)');
    G = single(ismember(G,okg));
  end
  
else
  G = [];
end

if opts.nrm
	if opts.nrmFull
    Xr = reshape(X,1,1,wSize(1)*wSize(2)*wSize(3),wSize(4));
    Xnrm = vl_nnnormalizelp(Xr,[],'p',2,'epsilon',1e-8);
    X_ = reshape(Xnrm,wSize(1)*wSize(2)*wSize(3),wSize(4));
  else 
    Xnrm = vl_nnnormalizelp(X,[],'p',2,'epsilon',1e-8);
    X_ = reshape(Xnrm,wSize(1)*wSize(2)*wSize(3),wSize(4));
  end
else
	X_ = reshape(X,wSize(1)*wSize(2)*wSize(3),wSize(4));
end

wht = X_'*X_;
if ~isempty(G)
  wht = wht.*G;
end

denom = numel(wht)-(wSize(4));
wht(logical(eye(wSize(4)))) = 0;

if nargin <= 1 || isempty(dzdy)
  Y = sum( abs(wht(:)).^opts.p  ) * (1/denom);
else 

  dwht = 2*sign(wht) .* ( (opts.p * abs(wht) ).^(opts.p-1) )  * (1/denom) ;

  DW = dzdy*(X_*dwht');
  Y = reshape(DW,wSize);

  if opts.nrm
  	if opts.nrmFull
      Y_ = reshape(Y,1,1,wSize(1)*wSize(2)*wSize(3),wSize(4));
      Y_ = vl_nnnormalizelp(Xr,Y_,'p',2,'epsilon',1e-8);
      Y = reshape(Y_,wSize); 
    else
      Y = vl_nnnormalizelp(X,Y,'p',2,'epsilon',1e-8);
    end
  end

end



% --------------------------------------------------------------------
function y = zerosLike(x)
% --------------------------------------------------------------------
if isa(x,'gpuArray')
  y = gpuArray.zeros(size(x),'single') ;
else
  y = zeros(size(x),'single') ;
end
