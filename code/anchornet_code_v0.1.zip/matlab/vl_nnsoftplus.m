function Y = vl_nnsoftplus(X,dzdY)

if isempty(dzdY)
	softMode = X < 30;
	Y = X;
	Y(softMode) = log(1+exp(X(softMode)));
else
	Y = vl_nnsigmoid(X).*dzdY;
end	