function [Y] = vl_nnwhitenhmap(X,dzdy,varargin)
% Copyright (C) 2014-15 Andrea Vedaldi.
% All rights reserved.
%
% This file is part of the VLFeat library and is made available under
% the terms of the BSD license (see the COPYING file).

opts.p = 2;
opts.nrm = false;
opts = vl_argparse(opts,varargin) ;

xSize = [size(X,1) size(X,2) size(X,3) size(X,4)] ;

assert(xSize(3)>1);

% zero_ = single(sum(sum(abs(X),1),2) <= 1e-8);
% X = bsxfun(@plus,X,zero_*1e-7);

if opts.nrm
	Xn_ = vl_nnnormalizelphmap(X,[],'p',2,'epsilon',1e-2);
  X_ = reshape(Xn_,xSize(1)*xSize(2),xSize(3),xSize(4));
else
	X_ = reshape(X,xSize(1)*xSize(2),xSize(3),xSize(4));
end

nIm = xSize(4);

Y = {};

for imi = 1:nIm
  wht = X_(:,:,imi)'*X_(:,:,imi);
  denom = numel(wht)-(xSize(3));
  wht(logical(eye(xSize(3)))) = 0;
  if nargin <= 1 || isempty(dzdy)
    Y{imi} = sum( abs(wht(:)).^opts.p  ) * (1/denom);
  else
    dwht = 2*sign(wht) .* ( (opts.p * abs(wht) ).^(opts.p-1) )  * (1/denom) ;
    DW = dzdy*(X_(:,:,imi)*dwht');
    Y{imi} = reshape(DW,xSize(1:3));
  end

end
Y = cat(4,Y{:});

if opts.nrm && ~isempty(dzdy)
    Y = vl_nnnormalizelphmap(X,Y,'p',2,'epsilon',1e-2);
end

if isempty(dzdy)
  Y = sum(Y(:));
end


% --------------------------------------------------------------------
function y = zerosLike(x)
% --------------------------------------------------------------------
if isa(x,'gpuArray')
  y = gpuArray.zeros(size(x),'single') ;
else
  y = zeros(size(x),'single') ;
end
