function Y = vl_nnloss_anchornet(X,c,dzdy,varargin)
%VL_NNLOSS CNN categorical or attribute loss.
%   Y = VL_NNLOSS(X, C) computes the loss incurred by the prediction
%   scores X given the categorical labels C.
%
%   The prediction scores X are organised as a field of prediction
%   vectors, represented by a H x W x D x N array. The first two
%   dimensions, H and W, are spatial and correspond to the height and
%   width of the field; the third dimension D is the number of
%   categories or classes; finally, the dimension N is the number of
%   data items (images) packed in the array.
%
%   While often one has H = W = 1, the case W, H > 1 is useful in
%   dense labelling problems such as image segmentation. In the latter
%   case, the loss is summed across pixels (contributions can be
%   weighed using the `InstanceWeights` option described below).
%
%   The array C contains the categorical labels. In the simplest case,
%   C is an array of integers in the range [1, D] with N elements
%   specifying one label for each of the N images. If H, W > 1, the
%   same label is implicitly applied to all spatial locations.
%
%   In the second form, C has dimension H x W x 1 x N and specifies a
%   categorical label for each spatial location.
%
%   In the third form, C has dimension H x W x D x N and specifies
%   attributes rather than categories. Here elements in C are either
%   +1 or -1 and C, where +1 denotes that an attribute is present and
%   -1 that it is not. The key difference is that multiple attributes
%   can be active at the same time, while categories are mutually
%   exclusive. By default, the loss is *summed* across attributes
%   (unless otherwise specified using the `InstanceWeights` option
%   described below).
%
%   DZDX = VL_NNLOSS(X, C, DZDY) computes the derivative of the block
%   projected onto the output derivative DZDY. DZDX and DZDY have the
%   same dimensions as X and Y respectively.
%
%   VL_NNLOSS() supports several loss functions, which can be selected
%   by using the option `type` described below. When each scalar c in
%   C is interpreted as a categorical label (first two forms above),
%   the following losses can be used:
%
%   Classification error:: `classerror`
%     L(X,c) = (argmax_q X(q) ~= c). Note that the classification
%     error derivative is flat; therefore this loss is useful for
%     assessment, but not for training a model.
%
%   Top-K classification error:: `topkerror`
%     L(X,c) = (rank X(c) in X <= K). The top rank is the one with
%     highest score. For K=1, this is the same as the
%     classification error. K is controlled by the `topK` option.
%
%   Log loss:: `log`
%     L(X,c) = - log(X(c)). This function assumes that X(c) is the
%     predicted probability of class c (hence the vector X must be non
%     negative and sum to one).
%
%   Softmax log loss (multinomial logistic loss):: `softmaxlog`
%     L(X,c) = - log(P(c)) where P(c) = exp(X(c)) / sum_q exp(X(q)).
%     This is the same as the `log` loss, but renormalizes the
%     predictions using the softmax function.
%
%   Multiclass hinge loss:: `mhinge`
%     L(X,c) = max{0, 1 - X(c)}. This function assumes that X(c) is
%     the score margin for class c against the other classes.  See
%     also the `mmhinge` loss below.
%
%   Multiclass structured hinge loss:: `mshinge`
%     L(X,c) = max{0, 1 - M(c)} where M(c) = X(c) - max_{q ~= c}
%     X(q). This is the same as the `mhinge` loss, but computes the
%     margin between the prediction scores first. This is also known
%     the Crammer-Singer loss, an example of a structured prediction
%     loss.
%
%   When C is a vector of binary attribures c in (+1,-1), each scalar
%   prediction score x is interpreted as voting for the presence or
%   absence of a particular attribute. The following losses can be
%   used:
%
%   Binary classification error:: `binaryerror`
%     L(x,c) = (sign(x - t) ~= c). t is a threshold that can be
%     specified using the `threshold` option and defaults to zero. If
%     x is a probability, it should be set to 0.5.
%
%   Binary log loss:: `binarylog`
%     L(x,c) = - log(c(x-0.5) + 0.5). x is assumed to be the
%     probability that the attribute is active (c=+1). Hence x must be
%     a number in the range [0,1]. This is the binary version of the
%     `log` loss.
%
%   Logistic log loss:: `logisticlog`
%     L(x,c) = log(1 + exp(- cx)). This is the same as the `binarylog`
%     loss, but implicitly normalizes the score x into a probability
%     using the logistic (sigmoid) function: p = sigmoid(x) = 1 / (1 +
%     exp(-x)). This is also equivalent to `softmaxlog` loss where
%     class c=+1 is assigned score x and class c=-1 is assigned score
%     0.
%
%   Hinge loss:: `hinge`
%     L(x,c) = max{0, 1 - cx}. This is the standard hinge loss for
%     binary classification. This is equivalent to the `mshinge` loss
%     if class c=+1 is assigned score x and class c=-1 is assigned
%     score 0.
%
%   VL_NNLOSS(...,'OPT', VALUE, ...) supports these additionals
%   options:
%
%   InstanceWeights:: []
%     Allows to weight the loss as L'(x,c) = WGT L(x,c), where WGT is
%     a per-instance weight extracted from the array
%     `InstanceWeights`. For categorical losses, this is either a H x
%     W x 1 or a H x W x 1 x N array. For attribute losses, this is
%     either a H x W x D or a H x W x D x N array.
%
%   TopK:: 5
%     Top-K value for the top-K error. Note that K should not
%     exceed the number of labels.
%
%   See also: VL_NNSOFTMAX().

% Copyright (C) 2014-15 Andrea Vedaldi.
% Copyright (C) 2016 Karel Lenc.
% All rights reserved.
%
% This file is part of the VLFeat library and is made available under
% the terms of the BSD license (see the COPYING file).

opts.instanceWeights = [] ;
opts.classWeights = [] ;
opts.threshold = 0 ;
opts.loss = 'softmaxlog' ;
opts.topK = 5 ;
opts = vl_argparse(opts, varargin, 'nonrecursive') ;

inputSize = [size(X,1) size(X,2) size(X,3) size(X,4)] ;

gpu = isa(X,'gpuArray');

% Form 1: C has one label per image. In this case, get C in form 2 or
% form 3.
c = gather(c) ;
if numel(c) == inputSize(4)
  c = reshape(c, [1 1 1 inputSize(4)]) ;
  c = repmat(c, inputSize(1:2)) ;
end

hasIgnoreLabel = any(c(:) == 0);

% --------------------------------------------------------------------
% Spatial weighting
% --------------------------------------------------------------------

labelSize = [size(c,1) size(c,2) size(c,3) size(c,4)] ;
if ~isempty(c)
  assert(isequal(labelSize(1:2), inputSize(1:2))) ;
  assert(labelSize(4) == inputSize(4)) ;
end
instanceWeights = [] ;

switch lower(opts.loss)
  case {'classerror', 'topkerror', 'log', 'softmaxlog', 'mhinge', 'mshinge'}
    % there must be one categorical label per prediction vector
    assert(labelSize(3) == 1) ;

    if hasIgnoreLabel
      % null labels denote instances that should be skipped
      instanceWeights = cast(c(:,:,1,:) ~= 0, 'like', c) ;
    end

  case {'binaryerror', 'binarylog', 'logistic', 'hinge', 'corr'}

    % there must be one categorical label per prediction scalar
    assert(labelSize(3) == inputSize(3)) ;

    if hasIgnoreLabel
      % null labels denote instances that should be skipped
      instanceWeights = cast(c ~= 0, 'like', c) ;
    end

  case {'entropy', 'binarylogmulti', 'hingebsx'}
    instanceWeights = X;
    instanceWeights(:) = 1;
  
  case {'l2'}
    instanceWeights = c(:,:,1,:);
    instanceWeights(:) = 1;  
    % instanceWeights = cast(c(:,:,1,:), 'like', c) ;
    

  case {'activity'}
    instanceWeights = single(c ~= 0) ;

  otherwise
    error('Unknown loss ''%s''.', opts.loss) ;
end

if ~isempty(opts.instanceWeights)
  % important: this code needs to broadcast opts.instanceWeights to
  % an array of the same size as c
  if isempty(instanceWeights)
    instanceWeights = bsxfun(@times, onesLike(c), opts.instanceWeights) ;
  else
    instanceWeights = bsxfun(@times, instanceWeights, opts.instanceWeights);
  end
end

% --------------------------------------------------------------------
% Do the work
% --------------------------------------------------------------------

switch lower(opts.loss)
  case {'log', 'softmaxlog', 'mhinge', 'mshinge'}
    % from category labels to indexes
    numPixelsPerImage = prod(inputSize(1:2)) ;
    numPixels = numPixelsPerImage * inputSize(4) ;
    imageVolume = numPixelsPerImage * inputSize(3) ;

    n = reshape(0:numPixels-1,labelSize) ;
    offset = 1 + mod(n, numPixelsPerImage) + ...
             imageVolume * fix(n / numPixelsPerImage) ;
    ci = offset + numPixelsPerImage * max(c - 1,0) ;
end

if nargin <= 2 || isempty(dzdy)
  switch lower(opts.loss)
    case 'classerror'
      [~,chat] = max(X,[],3) ;
      t = cast(c ~= chat, 'like', c) ;
    case 'topkerror'
      [~,predictions] = sort(X,3,'descend') ;
      t = 1 - sum(bsxfun(@eq, c, predictions(:,:,1:opts.topK,:)), 3) ;
    case 'log'
      t = - log(X(ci)) ;
    case 'softmaxlog'
      Xmax = max(X,[],3) ;
      ex = exp(bsxfun(@minus, X, Xmax)) ;
      t = Xmax + log(sum(ex,3)) - X(ci) ;
    case 'mhinge'
      t = max(0, 1 - X(ci)) ;
    case 'mshinge'
      Q = X ;
      Q(ci) = -inf ;
      t = max(0, 1 - X(ci) + max(Q,[],3)) ;
    case 'binaryerror'
      t = cast(sign(X - opts.threshold) ~= c, 'like', c) ;
    case 'binarylog'
      t = -log(c.*(X-0.5) + 0.5) ;
    case 'binarylogmulti'
      t = bsxfun(@times,c,(X-0.5)) + 0.5;
      t = -log(max(t,1e-20)) ;
      if any(~isfinite(t(:)))
        error('underflow of log!');
      end
    case 'logistic'
      %t = log(1 + exp(-c.*X)) ;
      a = -c.*X ;
      b = max(0, a) ;
      t = b + log(exp(-b) + exp(a-b)) ;
    case 'hinge'
      t = max(0, 1 - c.*X) ;
    case 'hingebsx'
      t = max(0, 1 - bsxfun(@times,c,X)) ;
    case 'corr'
      t = -c.*X;
    case 'activity'
      instanceWeights = zerosLike(1);
      instanceWeights(:) = 1;
      t = mean(abs(X(:)));
    case 'entropy'
      t = - X.*log( max(X,1e-15) );
    case 'l2'
      t = vl_nnpdist(X, c, 2, 'aggregate', false);
      % if numel(t)>1
      %   keyboard
      % end
    case 'reversehuber'
      df = X-c;
  end
  if ~isempty(instanceWeights)
    Y = instanceWeights(:)' * t(:) ;
  else
    Y = sum(t(:));
  end
else
  if ~isempty(instanceWeights)
    dzdy = dzdy .* instanceWeights ; 
  end
  switch lower(opts.loss)
    case {'classerror', 'topkerror'}
      Y = zerosLike(X) ;
    case 'log'
      Y = zerosLike(X) ;
      Y(ci) = - dzdy ./ max(X(ci), 1e-8) ;
    case 'softmaxlog'
      Xmax = max(X,[],3) ;
      ex = exp(bsxfun(@minus, X, Xmax)) ;
      Y = bsxfun(@rdivide, ex, sum(ex,3)) ;
      Y(ci) = Y(ci) - 1 ;
      Y = bsxfun(@times, dzdy, Y) ;
    case 'mhinge'
      Y = zerosLike(X) ;
      Y(ci) = - dzdy .* (X(ci) < 1) ;
    case 'mshinge'
      Q = X ;
      Q(ci) = -inf ;
      [~, q] = max(Q,[],3) ;
      qi = offset + numPixelsPerImage * (q - 1) ;
      W = dzdy .* (X(ci) - X(qi) < 1) ;
      Y = zerosLike(X) ;
      Y(ci) = - W ;
      Y(qi) = + W ;
    case 'binaryerror'
      Y = zerosLike(X) ;
    case 'binarylog'
      Y = - dzdy ./ (X + (c-1)*0.5) ;
    case 'binarylogmulti'
      Y = - dzdy ./ (bsxfun(@plus,X,(c-1)*0.5)) ;
    case 'logistic'
      % t = exp(-Y.*X) / (1 + exp(-Y.*X)) .* (-Y)
      % t = 1 / (1 + exp(Y.*X)) .* (-Y)
      Y = - dzdy .* c ./ (1 + exp(c.*X)) ;
    case 'hinge'
      Y = - dzdy .* c .* (c.*X < 1) ;
    case 'hingebsx'
      Y = - dzdy .* bsxfun(@times,c,bsxfun(@times,c,X) < 1) ;
    case 'corr'
      if gpu
        Y = - gpuArray(dzdy) .* gpuArray(c);
      else
        Y = - dzdy .* c; 
      end
    case 'entropy'
      % Y = X.*log( max(X,1e-20) );
      Y = - dzdy .* ( log( max(X,1e-15) ) + 1 ) ;
    case 'activity'
      Y = zerosLike(X);
    case 'l2'
      Y = vl_nnpdist(X, c, 2, dzdy, 'aggregate', true);
    case 'reversehuber'
      error('not done');
  end
end

% --------------------------------------------------------------------
function y = zerosLike(x)
% --------------------------------------------------------------------
if isa(x,'gpuArray')
  y = gpuArray.zeros(size(x),classUnderlying(x)) ;
else
  y = zeros(size(x),'like',x) ;
end

% --------------------------------------------------------------------
function y = onesLike(x)
% --------------------------------------------------------------------
if isa(x,'gpuArray')
  y = gpuArray.ones(size(x),classUnderlying(x)) ;
else
  y = ones(size(x),'like',x) ;
end
