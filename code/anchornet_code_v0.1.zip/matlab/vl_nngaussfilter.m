function Y = vl_nngaussfilter(X,g,dzdY)

	g1 = g{1};
	g2 = g{2};

	sz = (size(g{1},1)-1)/2 ;
	assert(round(sz)==sz) ;
    
    if ~isempty(dzdY)
    	Xf1  = vl_nnconv(X,g1,[],'pad', [sz sz 0 0],'stride',1);
        dXf2 = vl_nnconv(Xf1,g2,[],dzdY,'pad', [0 0 sz sz],'stride',1);
        Y    = vl_nnconv(X,g1,[],dXf2,'pad', [sz sz 0 0],'stride',1);
    else
		Xf1 = vl_nnconv(X,g1,[],'pad', [sz sz 0 0],'stride',1);
		Y   = vl_nnconv(Xf1,g2,[],'pad', [0 0 sz sz],'stride',1);
    end

    % if isa(g{1},'gpuArray')
    % 	Y = gpuArray(Y);
    % end
    % Y = gpuArray(Y);
    % keyboard